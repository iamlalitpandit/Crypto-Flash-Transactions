"""Pure functions: receipt (+ optional call trace) -> structured analysis.

No network access here so everything is unit-testable.
"""
from __future__ import annotations

from collections import defaultdict
from typing import Any

from . import chain as C


def _addr(topic_or_word: str) -> str:
    return "0x" + topic_or_word[-40:].lower()


def _words(data: str) -> list[str]:
    d = data[2:] if data.startswith("0x") else data
    return [d[i:i + 64] for i in range(0, len(d), 64)]


def _u(word: str) -> int:
    return int(word, 16) if word else 0


def decode_flashloans(logs: list[dict], uni3_pool_tokens: dict[str, tuple[str, str]] | None = None) -> list[dict]:
    """Return one dict per flash-loan event: provider, token, amount, fee, log_index, receiver."""
    out = []
    uni3_pool_tokens = uni3_pool_tokens or {}
    for lg in logs:
        topics = lg.get("topics") or []
        if not topics:
            continue
        t0 = topics[0].lower()
        addr = lg["address"].lower()
        li = int(lg["logIndex"], 16) if isinstance(lg["logIndex"], str) else lg["logIndex"]
        w = _words(lg.get("data", "0x"))
        try:
            if t0 == C.T_AAVE3_FLASH and addr == C.AAVE_V3_POOL and len(topics) == 4 and len(w) >= 4:
                out.append(dict(provider="Aave V3", receiver=_addr(topics[1]), token=_addr(topics[2]),
                                amount=_u(w[1]), fee=_u(w[3]), log_index=li,
                                debt_opened=_u(w[2]) != 0))
            elif t0 == C.T_AAVE2_FLASH and addr == C.AAVE_V2_POOL and len(topics) == 4 and len(w) >= 2:
                out.append(dict(provider="Aave V2", receiver=_addr(topics[1]), token=_addr(topics[3]),
                                amount=_u(w[0]), fee=_u(w[1]), log_index=li, debt_opened=False))
            elif t0 == C.T_FLASHLOAN_4 and addr == C.BALANCER_V2_VAULT and len(topics) == 3 and len(w) >= 2:
                out.append(dict(provider="Balancer V2", receiver=_addr(topics[1]), token=_addr(topics[2]),
                                amount=_u(w[0]), fee=_u(w[1]), log_index=li, debt_opened=False))
            elif t0 == C.T_FLASHLOAN_4 and addr == C.MAKER_DSS_FLASH and len(topics) == 2 and len(w) >= 3:
                out.append(dict(provider="Maker DssFlash", receiver=_addr(topics[1]), token=_addr(w[0]),
                                amount=_u(w[1]), fee=_u(w[2]), log_index=li, debt_opened=False))
            elif t0 == C.T_MORPHO_FLASH and addr == C.MORPHO_BLUE and len(topics) == 3 and len(w) >= 1:
                out.append(dict(provider="Morpho Blue", receiver=_addr(topics[1]), token=_addr(topics[2]),
                                amount=_u(w[0]), fee=0, log_index=li, debt_opened=False))
            elif t0 == C.T_UNI3_FLASH and len(topics) == 3 and len(w) >= 4:
                toks = uni3_pool_tokens.get(addr)
                a0, a1, p0, p1 = (_u(x) for x in w[:4])
                if toks is None:
                    out.append(dict(provider="Uniswap V3", receiver=_addr(topics[2]), token=addr + ":?",
                                    amount=0, fee=0, log_index=li, debt_opened=False))
                    continue
                if a0 or p0:
                    out.append(dict(provider="Uniswap V3", receiver=_addr(topics[2]), token=toks[0],
                                    amount=a0, fee=p0, log_index=li, debt_opened=False))
                if a1 or p1:
                    out.append(dict(provider="Uniswap V3", receiver=_addr(topics[2]), token=toks[1],
                                    amount=a1, fee=p1, log_index=li * 1000 + 1, debt_opened=False))
        except (ValueError, IndexError):
            continue
    return out


def eth_flows_from_trace(trace: Any, fmt: str, beneficiaries: set[str], coinbase: str | None) -> tuple[int, int]:
    """Return (net_eth_delta_wei_for_beneficiaries, eth_paid_to_coinbase_wei) from a call trace.

    fmt = "debug" (geth callTracer nested tree) or "trace" (parity trace_transaction flat list).
    The top-level call value (EOA -> contract) is internal to the beneficiary set when both are in it.
    """
    net = 0
    bribe = 0
    cb = (coinbase or "").lower()

    def handle(frm: str, to: str, value: int, call_type: str):
        nonlocal net, bribe
        if value == 0 or call_type in ("delegatecall", "staticcall", "DELEGATECALL", "STATICCALL"):
            return
        frm, to = (frm or "").lower(), (to or "").lower()
        fin, tin = frm in beneficiaries, to in beneficiaries
        if fin and not tin:
            net -= value
            if cb and to == cb:
                bribe += value
        elif tin and not fin:
            net += value

    if fmt == "debug":
        stack = [trace]
        while stack:
            node = stack.pop()
            if not isinstance(node, dict):
                continue
            if node.get("error") and node is not trace:
                # reverted sub-call: value transfer did not happen; skip subtree
                continue
            v = node.get("value") or "0x0"
            handle(node.get("from"), node.get("to"), int(v, 16) if isinstance(v, str) else int(v),
                   (node.get("type") or "").lower())
            stack.extend(node.get("calls") or [])
    elif fmt == "trace":
        for fr in trace or []:
            if fr.get("error"):
                continue
            act = fr.get("action") or {}
            v = act.get("value") or "0x0"
            ttype = (fr.get("type") or "")
            ctype = (act.get("callType") or ttype or "").lower()
            if ttype == "suicide":
                handle(act.get("address"), act.get("refundAddress"), int(act.get("balance", "0x0"), 16), "call")
                continue
            if ttype not in ("call", "create"):
                continue
            to = act.get("to") or ((fr.get("result") or {}).get("address"))
            handle(act.get("from"), to, int(v, 16) if isinstance(v, str) else int(v), ctype)
    return net, bribe


def analyze_receipt(receipt: dict, uni3_pool_tokens: dict | None = None, native: dict | None = None) -> dict:
    """Analyze one transaction receipt.

    Beneficiary set = {tx.from (EOA), tx.to (bot/contract)}. Net token deltas are measured for
    this set. Gas fee is paid by tx.from.
    Native ETH accounting (`native` = {"delta": wei, "bribe": wei, "mode": "trace"|"balance"}):
      * trace   : exact native-ETH flows from the call tree, incl. coinbase (builder) bribes.
      * balance : archive eth_getBalance diff of tx.from + tx.to over the block, gas added back.
      * None    : conservative mode -> WETH Withdrawal by the bot is treated as value leaving
                  (bots usually unwrap to pay the builder), WETH Deposit is treated as neutral.
                  Under-states profit for routes through native-ETH pools (e.g. Uniswap V4).
    """
    has_native = native is not None
    logs = receipt.get("logs") or []
    frm = (receipt.get("from") or "").lower()
    to = (receipt.get("to") or "").lower()
    bene = {a for a in (frm, to) if a}

    flows: dict[str, int] = defaultdict(int)
    swaps = []
    liqs = set()
    for lg in logs:
        topics = [t.lower() for t in (lg.get("topics") or [])]
        if not topics:
            continue
        t0 = topics[0]
        addr = lg["address"].lower()
        if t0 == C.T_TRANSFER and len(topics) == 3:
            try:
                val = int(lg["data"], 16) if lg.get("data") not in (None, "0x") else 0
            except ValueError:
                continue
            f, t = _addr(topics[1]), _addr(topics[2])
            if t in bene and f not in bene:
                flows[addr] += val
            elif f in bene and t not in bene:
                flows[addr] -= val
        elif addr == C.WETH and t0 == C.T_WETH_DEPOSIT and len(topics) == 2:
            # with trace: WETH +, and the ETH sent to WETH shows up as ETH - in the call tree.
            # without trace: ignore entirely (ETH -> WETH conversion is value-neutral).
            if _addr(topics[1]) in bene and has_native:
                flows[C.WETH] += int(lg["data"], 16)
        elif addr == C.WETH and t0 == C.T_WETH_WITHDRAWAL and len(topics) == 2:
            if _addr(topics[1]) in bene:
                flows[C.WETH] -= int(lg["data"], 16)
                # with native accounting the returned ETH is captured; without it we assume it left
        elif t0 in C.SWAP_TOPICS:
            pool = topics[1] if C.SWAP_TOPICS[t0] in ("UniV4", "BalancerV2") else addr
            swaps.append(dict(venue=C.SWAP_TOPICS[t0], pool=pool))
        elif t0 in C.LIQUIDATION_TOPICS:
            liqs.add(C.LIQUIDATION_TOPICS[t0])

    bribe = 0
    eth_mode = "conservative"
    if has_native:
        flows[C.ETH_PSEUDO] += int(native.get("delta", 0))
        bribe = int(native.get("bribe", 0))
        eth_mode = native.get("mode", "trace")

    gas_used = int(receipt.get("gasUsed", "0x0"), 16)
    egp = int(receipt.get("effectiveGasPrice", "0x0") or "0x0", 16)
    flashes = decode_flashloans(logs, uni3_pool_tokens)

    return dict(
        hash=receipt["transactionHash"].lower(),
        block=int(receipt["blockNumber"], 16),
        from_addr=frm,
        to_addr=to,
        status=int(receipt.get("status", "0x1"), 16),
        gas_used=gas_used,
        gas_price=egp,
        gas_fee_wei=gas_used * egp,
        flashloans=flashes,
        swaps=swaps,
        n_swaps=len(swaps),
        n_pools=len({s["pool"] for s in swaps}),
        venues=sorted({s["venue"] for s in swaps}),
        liquidations=sorted(liqs),
        flows={k: v for k, v in flows.items() if v != 0},
        bribe_wei=bribe,
        eth_mode=eth_mode,
    )


def classify(n_swaps: int, n_pools: int, liquidations: list[str], usd_deltas: dict[str, float | None],
             dust_usd: float = 0.01, gross_usd: float = 0.0, flash_usd: float = 0.0,
             max_margin: float = 0.05) -> str:
    """Classify a flash-loan tx.

    usd_deltas: token -> USD value of beneficiary delta (None if unpriced; sign still known via raw).
      liquidation        : a lending-protocol liquidation event fired in the tx
      arbitrage          : >=2 swaps over >=2 pools, the beneficiary only GAINED (or only lost)
                           tokens -> cyclic trade (borrow X -> swaps -> repay X), AND the gross result
                           is <= max_margin of the flash-loan volume (real arb margins are thin; a big
                           one-sided delta means capital moved in/out, e.g. a lending deposit/withdraw)
      position_mgmt      : swaps present but beneficiary both gained and lost different tokens
                           (collateral swap / leverage / refinance)
      single_swap        : exactly one swap (collateral swap, deleverage, ...)
      no_swap            : flash loan without DEX swap (refinance, migration, self-liquidation ...)
    """
    if liquidations:
        return "liquidation"
    if n_swaps == 0:
        return "no_swap"
    if n_swaps == 1 or n_pools < 2:
        return "single_swap"
    pos = neg = 0
    for tok, v in usd_deltas.items():
        if v is None:
            continue
        if v > dust_usd:
            pos += 1
        elif v < -dust_usd and tok not in (C.WETH, C.ETH_PSEUDO):
            # ETH/WETH outflows are treated as costs (builder bribes), not as "sold" tokens
            neg += 1
    if pos and neg:
        return "position_mgmt"
    if flash_usd > 0 and abs(gross_usd) > max_margin * flash_usd and abs(gross_usd) > 50:
        return "position_mgmt"
    return "arbitrage"


def is_reliable(category: str, eth_mode: str, venues: str, unpriced: int, weth_delta: int,
                n_flows: int = 1) -> bool:
    """Whether the USD profit of a tx can be trusted for profitability statistics."""
    if unpriced:
        return False
    if n_flows == 0:
        # no value reached tx.from/tx.to at all: profit (if any) went to an address we don't observe
        return False
    if eth_mode == "conservative" and (any(v in (venues or "") for v in ("UniV4", "Curve")) or weth_delta < 0):
        # native ETH may have moved (Uniswap V4 / Curve ETH pools / unwraps) but it was not observable
        return False
    return True
