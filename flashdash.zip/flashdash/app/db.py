import os
import sqlite3

SCHEMA = """
PRAGMA journal_mode=WAL;
CREATE TABLE IF NOT EXISTS meta (key TEXT PRIMARY KEY, value TEXT);

-- discovered flash-loan tx hashes waiting for receipt processing
CREATE TABLE IF NOT EXISTS pending (hash TEXT PRIMARY KEY, block INTEGER, ts INTEGER, tries INTEGER DEFAULT 0);

CREATE TABLE IF NOT EXISTS txs (
  hash TEXT PRIMARY KEY,
  block INTEGER, ts INTEGER, day TEXT,
  from_addr TEXT, to_addr TEXT,
  gas_used INTEGER, gas_price TEXT, gas_fee_wei TEXT,
  n_swaps INTEGER, n_pools INTEGER, venues TEXT, providers TEXT, liquidations TEXT,
  eth_mode TEXT, bribe_wei TEXT,
  -- filled by pricing step
  category TEXT,
  gross_usd REAL, gas_usd REAL, bribe_usd REAL, net_usd REAL,
  flash_usd REAL, fee_usd REAL,
  priced_tokens INTEGER, unpriced_tokens INTEGER, reliable INTEGER,
  priced_at INTEGER
);
CREATE INDEX IF NOT EXISTS ix_txs_ts ON txs(ts);
CREATE INDEX IF NOT EXISTS ix_txs_day_cat ON txs(day, category);
CREATE INDEX IF NOT EXISTS ix_txs_to ON txs(to_addr);
CREATE INDEX IF NOT EXISTS ix_txs_priced ON txs(priced_at);

CREATE TABLE IF NOT EXISTS flashloans (
  hash TEXT, log_index INTEGER, provider TEXT, token TEXT, amount TEXT, fee TEXT, receiver TEXT,
  PRIMARY KEY (hash, log_index)
);
CREATE INDEX IF NOT EXISTS ix_fl_hash ON flashloans(hash);

CREATE TABLE IF NOT EXISTS flows (hash TEXT, token TEXT, delta TEXT, PRIMARY KEY (hash, token));

CREATE TABLE IF NOT EXISTS prices (
  day TEXT, token TEXT, price REAL, confidence REAL, fetched_at INTEGER,
  PRIMARY KEY (day, token)
);
CREATE TABLE IF NOT EXISTS tokens (token TEXT PRIMARY KEY, symbol TEXT, decimals INTEGER);
CREATE TABLE IF NOT EXISTS uni3_pools (pool TEXT PRIMARY KEY, token0 TEXT, token1 TEXT);
CREATE TABLE IF NOT EXISTS block_meta (block INTEGER PRIMARY KEY, ts INTEGER, miner TEXT);
"""


def connect(path: str, readonly: bool = False) -> sqlite3.Connection:
    if not readonly:
        os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    if readonly:
        conn = sqlite3.connect(f"file:{path}?mode=ro", uri=True, check_same_thread=False, timeout=30)
    else:
        conn = sqlite3.connect(path, check_same_thread=False, timeout=30)
        conn.executescript(SCHEMA)
    conn.row_factory = sqlite3.Row
    return conn


def get_meta(conn, key, default=None):
    r = conn.execute("SELECT value FROM meta WHERE key=?", (key,)).fetchone()
    return r[0] if r else default


def set_meta(conn, key, value):
    conn.execute("INSERT INTO meta(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
                 (key, str(value)))
