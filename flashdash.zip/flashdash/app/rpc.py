"""Async JSON-RPC client with batching, rate limiting, retries and adaptive getLogs ranges."""
from __future__ import annotations

import asyncio
import logging
import random
import time
from typing import Any

import httpx

log = logging.getLogger("rpc")

RANGE_ERR_HINTS = ("range", "too many", "limit", "exceed", "block", "response size", "10000 results",
                   "query returned more", "timeout", "too large")


class RpcError(Exception):
    def __init__(self, err: Any):
        self.err = err
        super().__init__(str(err))

    @property
    def message(self) -> str:
        if isinstance(self.err, dict):
            return str(self.err.get("message", self.err))
        return str(self.err)


class RateLimiter:
    def __init__(self, rps: float):
        self.interval = 1.0 / rps if rps > 0 else 0
        self._next = 0.0
        self._lock = asyncio.Lock()

    async def wait(self):
        if not self.interval:
            return
        async with self._lock:
            now = time.monotonic()
            if self._next > now:
                await asyncio.sleep(self._next - now)
            self._next = max(now, self._next) + self.interval


class Rpc:
    def __init__(self, url: str, rps: float = 20, timeout: float = 60):
        self.url = url
        self.client = httpx.AsyncClient(timeout=timeout, http2=False,
                                        headers={"content-type": "application/json"})
        self.rl = RateLimiter(rps)
        self._id = 0
        self.batch_ok = True
        self.calls = 0

    async def close(self):
        await self.client.aclose()

    def _nid(self) -> int:
        self._id += 1
        return self._id

    async def _post(self, payload: Any, retries: int = 6) -> Any:
        delay = 1.0
        for attempt in range(retries):
            await self.rl.wait()
            try:
                r = await self.client.post(self.url, json=payload)
                self.calls += 1
                if r.status_code == 429 or r.status_code >= 500:
                    raise httpx.HTTPStatusError(f"HTTP {r.status_code}", request=r.request, response=r)
                return r.json()
            except (httpx.HTTPError, ValueError) as e:
                if attempt == retries - 1:
                    raise
                log.warning("rpc transport error (%s), retry in %.1fs", e, delay)
                await asyncio.sleep(delay + random.random())
                delay = min(delay * 2, 30)

    async def call(self, method: str, params: list) -> Any:
        delay = 1.0
        for attempt in range(5):
            resp = await self._post({"jsonrpc": "2.0", "id": self._nid(), "method": method, "params": params})
            if "error" in resp:
                msg = str(resp["error"]).lower()
                if any(k in msg for k in ("rate", "429", "capacity", "busy", "too many requests")) and attempt < 4:
                    await asyncio.sleep(delay)
                    delay *= 2
                    continue
                raise RpcError(resp["error"])
            return resp.get("result")
        raise RpcError("rate limited")

    async def batch(self, method: str, params_list: list[list]) -> list[Any]:
        """Return results aligned with params_list; failed items are None."""
        if not params_list:
            return []
        if self.batch_ok:
            ids = [self._nid() for _ in params_list]
            payload = [{"jsonrpc": "2.0", "id": i, "method": method, "params": p} for i, p in zip(ids, params_list)]
            try:
                resp = await self._post(payload)
            except Exception as e:  # noqa
                log.warning("batch failed: %s", e)
                resp = None
            if isinstance(resp, list):
                by_id = {x.get("id"): x for x in resp if isinstance(x, dict)}
                out = []
                for i in ids:
                    x = by_id.get(i)
                    out.append(x.get("result") if x and "result" in x else None)
                return out
            if isinstance(resp, dict) and "error" in resp:
                log.warning("RPC does not support batching (%s); falling back to single calls", resp["error"])
                self.batch_ok = False
        results = []
        for p in params_list:
            try:
                results.append(await self.call(method, p))
            except Exception:  # noqa
                results.append(None)
        return results

    async def batch_calls(self, calls: list[tuple[str, list]]) -> list[Any]:
        """Mixed-method batch; results aligned with calls, failed items None."""
        if not self.batch_ok:
            out = []
            for m, p in calls:
                try:
                    out.append(await self.call(m, p))
                except Exception:  # noqa
                    out.append(None)
            return out
        ids = [self._nid() for _ in calls]
        payload = [{"jsonrpc": "2.0", "id": i, "method": m, "params": p} for i, (m, p) in zip(ids, calls)]
        resp = await self._post(payload)
        if not isinstance(resp, list):
            self.batch_ok = False
            return await self.batch_calls(calls)
        by_id = {x.get("id"): x for x in resp if isinstance(x, dict)}
        return [(by_id.get(i) or {}).get("result") for i in ids]

    async def block_number(self) -> int:
        return int(await self.call("eth_blockNumber", []), 16)

    async def block_header(self, n: int) -> dict:
        return await self.call("eth_getBlockByNumber", [hex(n), False])


class LogScanner:
    """eth_getLogs over a range with adaptive span."""

    def __init__(self, rpc: Rpc, chunk: int, chunk_max: int):
        self.rpc = rpc
        self.chunk = chunk
        self.chunk_max = chunk_max

    async def get_logs(self, base_filter: dict, start: int, end: int) -> list[dict]:
        out = []
        cur = start
        while cur <= end:
            span = max(1, self.chunk)
            to = min(end, cur + span - 1)
            f = dict(base_filter, fromBlock=hex(cur), toBlock=hex(to))
            try:
                res = await self.rpc.call("eth_getLogs", [f])
            except RpcError as e:
                msg = e.message.lower()
                if span > 1 and any(h in msg for h in RANGE_ERR_HINTS):
                    self.chunk = max(1, span // 2)
                    log.info("getLogs span %d rejected (%s) -> %d", span, e.message[:120], self.chunk)
                    continue
                raise
            out.extend(res or [])
            cur = to + 1
            if self.chunk < self.chunk_max:
                self.chunk = min(self.chunk_max, int(self.chunk * 1.25) + 1)
        return out
