"""Indexer worker: backfill last N days of flash-loan txs, then follow the chain head.

Pipeline per block window:
  1. eth_getLogs for FlashLoan events (Aave V3/V2, Balancer V2, Morpho Blue, Maker, optional Uniswap V3 Flash)
  2. eth_getTransactionReceipt (batched) for each unique tx -> decode swaps, token flows, gas
  3. optional call trace for arbitrage candidates -> exact native ETH flows + builder bribes
  4. DefiLlama historical prices per UTC day -> USD gross / gas / net, classification
"""
from __future__ import annotations

import asyncio
import json
import logging
import math
import time
from datetime import datetime, timezone

import httpx

from . import chain as C
from . import config as cfg
from . import db
from .decode import analyze_receipt, classify, eth_flows_from_trace, is_reliable
from .prices import fetch_prices
from .rpc import LogScanner, Rpc, RpcError

log = logging.getLogger("indexer")
WINDOW = 1500  # blocks per pipeline step (~5h) so the dashboard fills progressively


def day_of(ts: int) -> str:
    return datetime.fromtimestamp(ts, tz=timezone.utc).strftime("%Y-%m-%d")


class Indexer:
    def __init__(self):
        if not cfg.RPC_URL:
            raise SystemExit("RPC_URL is not set (needs an archive-capable Ethereum RPC; see README)")
        self.conn = db.connect(cfg.DB_PATH)
        self.rpc = Rpc(cfg.RPC_URL, rps=cfg.MAX_RPS)
        self.scan_main = LogScanner(self.rpc, cfg.LOG_CHUNK, cfg.LOG_CHUNK_MAX)
        self.scan_uni3 = LogScanner(self.rpc, cfg.LOG_CHUNK, cfg.LOG_CHUNK_MAX)
        self.uni3_enabled = cfg.ENABLE_UNIV3_FLASH and db.get_meta(self.conn, "uni3_disabled") != "1"
        self.trace_mode = db.get_meta(self.conn, "trace_mode")  # resolved lazily
        self.http = httpx.AsyncClient()
        self.last_today_price = 0.0
        self.balance_off = False
        self.balance_ok = 0
        self.balance_fail = 0

    # ------------------------------------------------------------------ blocks
    async def block_ts(self, n: int) -> int:
        r = self.conn.execute("SELECT ts FROM block_meta WHERE block=?", (n,)).fetchone()
        if r and r[0]:
            return r[0]
        h = await self.rpc.block_header(n)
        ts = int(h["timestamp"], 16)
        self.conn.execute("INSERT OR REPLACE INTO block_meta(block,ts,miner) VALUES(?,?,?)",
                          (n, ts, (h.get("miner") or "").lower()))
        return ts

    async def block_miner(self, n: int) -> str:
        r = self.conn.execute("SELECT miner FROM block_meta WHERE block=?", (n,)).fetchone()
        if r and r[0]:
            return r[0]
        h = await self.rpc.block_header(n)
        miner = (h.get("miner") or "").lower()
        self.conn.execute("INSERT OR REPLACE INTO block_meta(block,ts,miner) VALUES(?,?,?)",
                          (n, int(h["timestamp"], 16), miner))
        return miner

    async def find_block_at(self, target_ts: int, head: int) -> int:
        head_ts = await self.block_ts(head)
        guess = max(1, head - (head_ts - target_ts) // 12)
        for _ in range(6):
            ts = await self.block_ts(guess)
            diff = ts - target_ts
            if abs(diff) < 24:
                break
            guess = max(1, guess - diff // 12)
        return guess

    # --------------------------------------------------------------- scanning
    async def scan_window(self, start: int, end: int) -> int:
        logs = await self.scan_main.get_logs(
            {"address": C.PROVIDER_ADDRESSES, "topics": [C.PROVIDER_TOPICS]}, start, end)
        if self.uni3_enabled:
            try:
                logs += await self.scan_uni3.get_logs({"topics": [C.T_UNI3_FLASH]}, start, end)
            except RpcError as e:
                log.warning("Uniswap V3 Flash scan disabled: RPC refused address-less filter (%s)", e.message[:150])
                self.uni3_enabled = False
                db.set_meta(self.conn, "uni3_disabled", "1")
        seen = {}
        for lg in logs:
            h = lg["transactionHash"].lower()
            if h in seen:
                continue
            b = int(lg["blockNumber"], 16)
            ts = lg.get("blockTimestamp")
            ts = int(ts, 16) if isinstance(ts, str) else (ts or 0)
            seen[h] = (b, ts)
        for h, (b, ts) in seen.items():
            if not ts:
                ts = await self.block_ts(b)
            self.conn.execute("INSERT OR IGNORE INTO pending(hash,block,ts) "
                              "SELECT ?,?,? WHERE NOT EXISTS (SELECT 1 FROM txs WHERE hash=?)", (h, b, ts, h))
        self.conn.commit()
        return len(seen)

    # ----------------------------------------------------------------- traces
    async def resolve_trace_mode(self, sample_hash: str):
        if self.trace_mode:
            return
        mode = cfg.TRACE_MODE
        if mode in ("trace", "debug", "off"):
            self.trace_mode = mode
        else:
            self.trace_mode = "off"
            for m in ("trace", "debug"):
                try:
                    r = await self.fetch_trace(sample_hash, m)
                    if r:
                        self.trace_mode = m
                        break
                except Exception as e:  # noqa
                    log.info("trace method %s unavailable: %s", m, str(e)[:120])
        log.info("TRACE_MODE resolved -> %s", self.trace_mode)
        db.set_meta(self.conn, "trace_mode", self.trace_mode)
        self.conn.commit()

    async def fetch_trace(self, h: str, mode: str):
        if mode == "trace":
            return await self.rpc.call("trace_transaction", [h])
        if mode == "debug":
            return await self.rpc.call("debug_traceTransaction", [h, {"tracer": "callTracer"}])
        return None

    async def native_eth(self, a: dict) -> dict | None:
        """Native ETH delta for {tx.from, tx.to}: trace if available, else archive balance diff."""
        bene = {x for x in (a["from_addr"], a["to_addr"]) if x}
        await self.resolve_trace_mode(a["hash"])
        if self.trace_mode in ("trace", "debug"):
            try:
                tr = await self.fetch_trace(a["hash"], self.trace_mode)
                if tr:
                    miner = await self.block_miner(a["block"])
                    net, bribe = eth_flows_from_trace(tr, self.trace_mode, bene, miner)
                    return {"delta": net, "bribe": bribe, "mode": "trace"}
            except Exception as e:  # noqa
                log.debug("trace failed for %s: %s", a["hash"], e)
        if self.balance_off:
            return None
        b, frm, to = a["block"], a["from_addr"], a["to_addr"]
        out = await self.rpc.batch_calls([
            ("eth_getBalance", [to, hex(b - 1)]), ("eth_getBalance", [to, hex(b)]),
            ("eth_getBalance", [frm, hex(b - 1)]), ("eth_getBalance", [frm, hex(b)]),
            ("eth_getTransactionCount", [frm, hex(b - 1)]), ("eth_getTransactionCount", [frm, hex(b)]),
        ])
        res, nonces = out[:4], out[4:]
        if any(r is None for r in res) or any(n is None for n in nonces):
            self.balance_fail += 1
            if self.balance_ok == 0 and self.balance_fail >= 25:
                log.warning("archive eth_getBalance unavailable on this RPC -> conservative ETH accounting")
                self.balance_off = True
            return None
        self.balance_ok += 1
        if int(nonces[1], 16) - int(nonces[0], 16) != 1:
            return None  # same EOA sent other txs in this block -> balance diff not attributable
        v = [int(x, 16) for x in res]
        delta = (v[1] - v[0]) + (v[3] - v[2]) + a["gas_fee_wei"]  # gas is accounted separately
        return {"delta": delta, "bribe": 0, "mode": "balance"}

    # ------------------------------------------------------------- uni3 pools
    async def uni3_tokens(self, pools: set[str]) -> dict:
        out = {}
        missing = []
        for p in pools:
            r = self.conn.execute("SELECT token0, token1 FROM uni3_pools WHERE pool=?", (p,)).fetchone()
            if r:
                out[p] = (r[0], r[1])
            else:
                missing.append(p)
        for p in missing:
            try:
                t0 = await self.rpc.call("eth_call", [{"to": p, "data": C.SEL_TOKEN0}, "latest"])
                t1 = await self.rpc.call("eth_call", [{"to": p, "data": C.SEL_TOKEN1}, "latest"])
                toks = ("0x" + t0[-40:].lower(), "0x" + t1[-40:].lower())
                self.conn.execute("INSERT OR REPLACE INTO uni3_pools VALUES(?,?,?)", (p, *toks))
                out[p] = toks
            except Exception as e:  # noqa
                log.debug("uni3 token lookup failed for %s: %s", p, e)
        return out

    # --------------------------------------------------------------- receipts
    async def process_pending(self):
        while True:
            rows = self.conn.execute(
                "SELECT hash, block, ts, tries FROM pending WHERE tries < 6 ORDER BY block LIMIT ?",
                (cfg.RECEIPT_BATCH * cfg.CONCURRENCY * 4,)).fetchall()
            if not rows:
                return
            sem = asyncio.Semaphore(cfg.CONCURRENCY)
            batches = [rows[i:i + cfg.RECEIPT_BATCH] for i in range(0, len(rows), cfg.RECEIPT_BATCH)]

            async def one(batch):
                async with sem:
                    res = await self.rpc.batch("eth_getTransactionReceipt", [[r["hash"]] for r in batch])
                    for r, rc in zip(batch, res):
                        if not rc:
                            self.conn.execute("UPDATE pending SET tries=tries+1 WHERE hash=?", (r["hash"],))
                            continue
                        try:
                            await self.store_receipt(rc, r["ts"])
                            self.conn.execute("DELETE FROM pending WHERE hash=?", (r["hash"],))
                        except Exception as e:  # noqa
                            log.exception("decode failed %s: %s", r["hash"], e)
                            self.conn.execute("UPDATE pending SET tries=tries+1 WHERE hash=?", (r["hash"],))

            await asyncio.gather(*(one(b) for b in batches))
            self.conn.commit()

    async def store_receipt(self, rc: dict, ts: int):
        uni3_pools = {lg["address"].lower() for lg in rc.get("logs", [])
                      if lg.get("topics") and lg["topics"][0].lower() == C.T_UNI3_FLASH}
        toks = await self.uni3_tokens(uni3_pools) if uni3_pools else {}
        a = analyze_receipt(rc, toks)
        candidate = a["n_swaps"] >= 2 and a["n_pools"] >= 2 and not a["liquidations"]
        if candidate:
            native = await self.native_eth(a)
            if native is not None:
                a = analyze_receipt(rc, toks, native=native)
        if not a["flashloans"]:
            return
        c = self.conn
        c.execute("""INSERT OR REPLACE INTO txs(hash,block,ts,day,from_addr,to_addr,gas_used,gas_price,gas_fee_wei,
                     n_swaps,n_pools,venues,providers,liquidations,eth_mode,bribe_wei,priced_at)
                     VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,NULL)""",
                  (a["hash"], a["block"], ts, day_of(ts), a["from_addr"], a["to_addr"], a["gas_used"],
                   str(a["gas_price"]), str(a["gas_fee_wei"]), a["n_swaps"], a["n_pools"],
                   ",".join(a["venues"]), ",".join(sorted({f["provider"] for f in a["flashloans"]})),
                   ",".join(a["liquidations"]), a["eth_mode"], str(a["bribe_wei"])))
        c.execute("DELETE FROM flows WHERE hash=?", (a["hash"],))
        c.executemany("INSERT INTO flows(hash,token,delta) VALUES(?,?,?)",
                      [(a["hash"], t, str(v)) for t, v in a["flows"].items()])
        c.executemany("INSERT OR REPLACE INTO flashloans(hash,log_index,provider,token,amount,fee,receiver) "
                      "VALUES(?,?,?,?,?,?,?)",
                      [(a["hash"], f["log_index"], f["provider"], f["token"], str(f["amount"]), str(f["fee"]),
                        f["receiver"]) for f in a["flashloans"]])

    # ---------------------------------------------------------------- pricing
    async def price_step(self, force_today: bool = False):
        now = int(time.time())
        today = day_of(now)
        days = [r[0] for r in self.conn.execute(
            "SELECT DISTINCT day FROM txs WHERE priced_at IS NULL ORDER BY day").fetchall()]
        refresh_today = force_today or (now - self.last_today_price > 1800)
        if refresh_today and today not in days and self.conn.execute(
                "SELECT 1 FROM txs WHERE day=? LIMIT 1", (today,)).fetchone():
            days.append(today)
        for d in days:
            await self.price_day(d, now, refresh=(d == today and refresh_today))
            if d == today and refresh_today:
                self.last_today_price = now

    async def price_day(self, d: str, now: int, refresh: bool):
        c = self.conn
        day_start = int(datetime.strptime(d, "%Y-%m-%d").replace(tzinfo=timezone.utc).timestamp())
        ts = min(day_start + 43200, now - 120)
        toks = {r[0] for r in c.execute(
            "SELECT DISTINCT f.token FROM flows f JOIN txs t ON t.hash=f.hash WHERE t.day=?", (d,))}
        toks |= {r[0] for r in c.execute(
            "SELECT DISTINCT f.token FROM flashloans f JOIN txs t ON t.hash=f.hash WHERE t.day=?", (d,))}
        toks.discard(C.ETH_PSEUDO)
        toks.add(C.WETH)
        if refresh:
            need = sorted(toks)
        else:
            have = {r[0] for r in c.execute("SELECT token FROM prices WHERE day=?", (d,))}
            need = sorted(toks - have)
        if need:
            got = await fetch_prices(self.http, cfg.PRICE_API, ts, need)
            for t in need:
                v = got.get(t)
                if v:
                    c.execute("INSERT OR REPLACE INTO prices VALUES(?,?,?,?,?)",
                              (d, t, v.get("price"), v.get("confidence", 1.0), now))
                    if v.get("decimals") is not None:
                        c.execute("INSERT OR REPLACE INTO tokens VALUES(?,?,?)", (t, v.get("symbol"), v["decimals"]))
                else:
                    c.execute("INSERT OR REPLACE INTO prices VALUES(?,?,NULL,NULL,?)", (d, t, now))
        price = {r[0]: (r[1], r[2]) for r in c.execute("SELECT token, price, confidence FROM prices WHERE day=?", (d,))}
        dec = {r[0]: r[1] for r in c.execute("SELECT token, decimals FROM tokens")}
        ethp = (price.get(C.WETH) or (None, None))[0]
        if not ethp:
            log.warning("no ETH price for %s yet; will retry", d)
            c.commit()
            return
        where = "day=?" if refresh else "day=? AND priced_at IS NULL"
        txs = c.execute(f"SELECT hash, gas_fee_wei, bribe_wei, n_swaps, n_pools, liquidations, eth_mode, venues "
                        f"FROM txs WHERE {where}",
                        (d,)).fetchall()
        for t in txs:
            h = t["hash"]
            usd_deltas = {}
            gross = 0.0
            priced = unpriced = 0
            for fr in c.execute("SELECT token, delta FROM flows WHERE hash=?", (h,)):
                tok, delta = fr[0], int(fr[1])
                key = C.WETH if tok == C.ETH_PSEUDO else tok
                p, conf = price.get(key, (None, None))
                dd = 18 if tok == C.ETH_PSEUDO else dec.get(key)
                if p is None or dd is None or (conf is not None and conf < cfg.MIN_PRICE_CONFIDENCE):
                    usd_deltas[tok] = math.copysign(math.inf, delta)
                    unpriced += 1
                    continue
                v = delta / (10 ** dd) * p
                if abs(v) > cfg.MAX_TOKEN_DELTA_USD:
                    usd_deltas[tok] = math.copysign(math.inf, delta)
                    unpriced += 1
                    continue
                usd_deltas[tok] = v
                gross += v
                priced += 1
            gas_usd = int(t["gas_fee_wei"]) / 1e18 * ethp
            bribe_usd = int(t["bribe_wei"] or 0) / 1e18 * ethp
            flash_usd = fee_usd = 0.0
            for fl in c.execute("SELECT token, amount, fee FROM flashloans WHERE hash=?", (h,)):
                p, _ = price.get(fl[0], (None, None))
                dd = dec.get(fl[0])
                if p is not None and dd is not None:
                    flash_usd += int(fl[1]) / 10 ** dd * p
                    fee_usd += int(fl[2]) / 10 ** dd * p
            liqs = [x for x in (t["liquidations"] or "").split(",") if x]
            cat = classify(t["n_swaps"], t["n_pools"], liqs, usd_deltas, gross_usd=gross, flash_usd=flash_usd,
                           max_margin=cfg.ARB_MAX_MARGIN)
            weth = c.execute("SELECT delta FROM flows WHERE hash=? AND token=?", (h, C.WETH)).fetchone()
            rel = is_reliable(cat, t["eth_mode"], t["venues"], unpriced, int(weth[0]) if weth else 0,
                              n_flows=priced + unpriced)
            c.execute("""UPDATE txs SET category=?, gross_usd=?, gas_usd=?, bribe_usd=?, net_usd=?, flash_usd=?,
                         fee_usd=?, priced_tokens=?, unpriced_tokens=?, reliable=?, priced_at=? WHERE hash=?""",
                      (cat, gross, gas_usd, bribe_usd, gross - gas_usd, flash_usd, fee_usd, priced, unpriced,
                       int(rel), now, h))
        c.commit()
        log.info("priced %s: %d txs", d, len(txs))

    # ------------------------------------------------------------------ prune
    def prune(self):
        cutoff = int(time.time() - (cfg.LOOKBACK_DAYS + 1) * 86400)
        c = self.conn
        c.execute("DELETE FROM flows WHERE hash IN (SELECT hash FROM txs WHERE ts < ?)", (cutoff,))
        c.execute("DELETE FROM flashloans WHERE hash IN (SELECT hash FROM txs WHERE ts < ?)", (cutoff,))
        c.execute("DELETE FROM txs WHERE ts < ?", (cutoff,))
        c.execute("DELETE FROM pending WHERE ts < ?", (cutoff,))
        c.execute("DELETE FROM block_meta WHERE ts < ?", (cutoff,))
        c.execute("DELETE FROM prices WHERE day < ?", (day_of(cutoff),))
        c.commit()

    # ------------------------------------------------------------------- main
    async def run(self):
        head = await self.rpc.block_number() - cfg.CONFIRMATIONS
        if db.get_meta(self.conn, "last_scanned") is None:
            start = await self.find_block_at(int(time.time() - cfg.LOOKBACK_DAYS * 86400), head)
            db.set_meta(self.conn, "backfill_start", start)
            db.set_meta(self.conn, "last_scanned", start - 1)
            self.conn.commit()
            log.info("backfill from block %d to %d (%d blocks)", start, head, head - start)
        while True:
            try:
                head = await self.rpc.block_number() - cfg.CONFIRMATIONS
                db.set_meta(self.conn, "head", head)
                cursor = int(db.get_meta(self.conn, "last_scanned"))
                while cursor < head:
                    db.set_meta(self.conn, "status", "backfilling" if head - cursor > 50 else "live")
                    end = min(head, cursor + WINDOW)
                    start_b = cursor + 1
                    t0 = time.time()
                    n = await self.scan_window(cursor + 1, end)
                    await self.process_pending()
                    cursor = end
                    db.set_meta(self.conn, "last_scanned", cursor)
                    db.set_meta(self.conn, "last_scanned_ts", await self.block_ts(cursor))
                    db.set_meta(self.conn, "updated_at", int(time.time()))
                    self.conn.commit()
                    await self.price_step()
                    log.info("blocks %d..%d: %d flash-loan txs (%.1fs, rpc calls=%d)", start_b, end, n,
                             time.time() - t0, self.rpc.calls)
                await self.process_pending()
                await self.price_step()
                self.prune()
                db.set_meta(self.conn, "updated_at", int(time.time()))
                db.set_meta(self.conn, "status", "live")
                self.conn.commit()
            except Exception as e:  # noqa
                log.exception("indexer loop error: %s", e)
                db.set_meta(self.conn, "last_error", f"{int(time.time())}: {str(e)[:300]}")
                self.conn.commit()
            await asyncio.sleep(cfg.POLL_SECONDS)


def main():
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
    logging.getLogger("httpx").setLevel(logging.WARNING)
    asyncio.run(Indexer().run())


if __name__ == "__main__":
    main()
