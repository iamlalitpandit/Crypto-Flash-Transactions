"use strict";
const $ = (s) => document.querySelector(s);
const CAT = {
  arbitrage: { label: "Arbitrage", color: "#338ced" },
  single_swap: { label: "Single swap", color: "#e76624" },
  position_mgmt: { label: "Position mgmt", color: "#00a888" },
  no_swap: { label: "No swap", color: "#d28e05" },
  liquidation: { label: "Liquidation", color: "#e24d8b" },
};
const CAT_ORDER = ["arbitrage", "single_swap", "position_mgmt", "no_swap", "liquidation"];
const PROFIT = "#338ced", LOSS = "#eb6263", INK2 = "#9c9c9c", GRID = "#303030", AXIS = "#474747";

const state = { days: 30, reliable: true, txCat: "arbitrage", txSort: "recent", txOffset: 0, txLimit: 50, bot: null, status: null };
const charts = {};

// ---------- formatting ----------
function usd(v, opts = {}) {
  if (v === null || v === undefined || Number.isNaN(v)) return "—";
  const sign = v < 0 ? "−" : (opts.plus && v > 0 ? "+" : "");
  const a = Math.abs(v);
  let s;
  if (a >= 1e9) s = (a / 1e9).toFixed(2) + "B";
  else if (a >= 1e6) s = (a / 1e6).toFixed(2) + "M";
  else if (a >= 1e4) s = (a / 1e3).toFixed(1) + "k";
  else if (a >= 100) s = a.toFixed(0);
  else if (a >= 1) s = a.toFixed(2);
  else s = a.toFixed(a === 0 ? 0 : 3);
  return sign + "$" + s;
}
const pct = (v, d = 1) => (v === null || v === undefined) ? "—" : (v * 100).toFixed(d) + "%";
const num = (v) => (v ?? 0).toLocaleString("en-US");
const short = (a) => a ? a.slice(0, 6) + "…" + a.slice(-4) : "—";
const cls = (v) => v > 0 ? "pos" : v < 0 ? "neg" : "";
const esc = (s) => String(s ?? "").replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
function ago(ts) {
  if (!ts) return "—";
  const s = Math.max(0, Date.now() / 1000 - ts);
  if (s < 90) return Math.round(s) + "s ago";
  if (s < 5400) return Math.round(s / 60) + "m ago";
  if (s < 172800) return Math.round(s / 3600) + "h ago";
  return Math.round(s / 86400) + "d ago";
}
const utc = (ts) => new Date(ts * 1000).toISOString().replace("T", " ").slice(0, 16);

async function api(path, params = {}) {
  const q = new URLSearchParams(params).toString();
  const r = await fetch(`/api/${path}${q ? "?" + q : ""}`);
  if (!r.ok) throw new Error(`${path}: ${r.status}`);
  return r.json();
}

// ---------- chart defaults ----------
function setupChartDefaults() {
  Chart.defaults.color = INK2;
  Chart.defaults.font.family = 'system-ui, -apple-system, "Segoe UI", Roboto, sans-serif';
  Chart.defaults.font.size = 11.5;
  Chart.defaults.borderColor = GRID;
  Chart.defaults.plugins.legend.labels.boxWidth = 10;
  Chart.defaults.plugins.legend.labels.boxHeight = 10;
  Chart.defaults.plugins.tooltip.backgroundColor = "#0b0b0b";
  Chart.defaults.plugins.tooltip.borderColor = "rgba(255,255,255,.15)";
  Chart.defaults.plugins.tooltip.borderWidth = 1;
  Chart.defaults.plugins.tooltip.padding = 10;
  Chart.defaults.plugins.tooltip.titleColor = "#efefef";
  Chart.defaults.plugins.tooltip.bodyColor = "#efefef";
  Chart.defaults.maintainAspectRatio = false;
}
function draw(id, config) {
  if (charts[id]) charts[id].destroy();
  charts[id] = new Chart(document.getElementById(id), config);
}
const barBase = { borderRadius: 4, borderSkipped: "start", borderWidth: 0, maxBarThickness: 28 };

// ---------- status ----------
async function loadStatus() {
  const s = await api("status");
  state.status = s;
  $("#chain").textContent = s.chain;
  const live = s.status === "live";
  $("#sync-dot").className = "dot " + (live ? "live" : "back");
  $("#sync-bar").style.width = (s.progress * 100).toFixed(1) + "%";
  $("#sync-text").textContent = live ? `Live · block ${num(s.last_scanned)}` :
    `Backfilling last ${s.lookback_days} days · ${(s.progress * 100).toFixed(1)}%`;
  const modes = Object.entries(s.arb_eth_modes || {}).map(([k, v]) => `${k}: ${num(v)}`).join(", ");
  $("#sync-meta").textContent = `${num(s.txs)} flash-loan txs indexed · data up to ${s.last_scanned_ts ? utc(s.last_scanned_ts) + " UTC" : "—"} · ` +
    `updated ${ago(s.updated_at)} · ETH accounting: ${s.trace_mode === "off" ? "balance/conservative" : s.trace_mode}` +
    (modes ? ` (${modes})` : "") + (s.pending ? ` · ${num(s.pending)} queued` : "");
}

// ---------- verdict + KPIs ----------
function renderVerdict(sum) {
  const a = sum.arb;
  const badge = $("#verdict-badge"), lead = $("#verdict-lead"), pts = $("#verdict-points");
  if (!a.count || a.count < 20) {
    badge.textContent = "Collecting data";
    lead.textContent = `Only ${a.count} measurable arbitrage txs in range so far. The verdict appears once enough data is indexed.`;
    pts.innerHTML = "";
    return;
  }
  let verdict;
  if (a.total_net > 0 && a.median_net > 0) verdict = "Yes — most landed arbitrage txs net a profit";
  else if (a.total_net > 0) verdict = "Profitable in aggregate — but only for a small group of bots";
  else verdict = "No — on-chain net result is negative";
  badge.textContent = verdict;
  $("#verdict-card").style.borderLeftColor = a.total_net > 0 ? PROFIT : LOSS;
  lead.innerHTML = `In the last <b>${sum.days} days</b>, <b>${num(a.count)}</b> flash-loan arbitrage txs were measured. ` +
    `<b>${pct(a.win_rate)}</b> of them made money after gas. The <b>median</b> tx ${a.median_net >= 0 ? "earned" : "lost"} ` +
    `<b class="${cls(a.median_net)}">${usd(a.median_net)}</b>; all of them together netted <b class="${cls(a.total_net)}">${usd(a.total_net, { plus: true })}</b>.`;
  const margin = a.flash_volume > 0 ? (a.total_gross / a.flash_volume) * 1e4 : null;
  const items = [];
  if (a.top5_share !== null) items.push(`<b>Concentration:</b> the top 5 of ${num(a.unique_bots)} bots captured <b>${pct(a.top5_share, 0)}</b> of all profit; only <b>${num(a.profitable_bots)}</b> bots were net-positive overall.`);
  if (a.gas_share_of_gross !== null) items.push(`<b>Gas cost:</b> gas (incl. builder priority tips) consumed <b>${pct(a.gas_share_of_gross, 0)}</b> of the gross trading profit (${usd(a.total_gas)} of ${usd(a.total_gross)}).`);
  if (margin !== null) items.push(`<b>Edge per dollar:</b> gross profit was <b>${margin.toFixed(3)} bps</b> of the ${usd(a.flash_volume)} borrowed — the flash loan supplies capital for free, it does not supply the opportunity.`);
  items.push(`<b>Tail:</b> ${num(a.above_100)} txs earned ≥ $100 and ${num(a.above_1000)} earned ≥ $1,000; 90% of txs fell between <b>${usd(a.p10)}</b> and <b>${usd(a.p90)}</b>.`);
  items.push(`<b>Caveat:</b> failed attempts revert and never show up on-chain (survivorship bias), so the real success rate per attempt is lower than ${pct(a.win_rate)}.`);
  pts.innerHTML = items.map((x) => `<li>${x}</li>`).join("");
  $("#excluded").textContent = sum.reliable_only && a.excluded_unreliable ? `${num(a.excluded_unreliable)} arb txs excluded (profit not measurable exactly)` : "";
}

function renderKpis(sum) {
  const a = sum.arb;
  const k = [
    ["Flash-loan txs", num(sum.total_flash_txs), "all categories"],
    ["Arbitrage txs (measured)", num(a.count), a.count_all !== a.count ? `${num(a.count_all)} incl. unmeasurable` : "cyclic multi-DEX trades"],
    ["Profitable after gas", pct(a.win_rate), `${num(a.wins)} winning txs`],
    ["Total net profit", usd(a.total_net, { plus: true }), "sum over measured arb txs", cls(a.total_net)],
    ["Median net / tx", usd(a.median_net, { plus: true }), `mean ${usd(a.mean_net, { plus: true })}`, cls(a.median_net)],
    ["Gas paid by arb bots", usd(a.total_gas), a.total_bribe ? `+ ${usd(a.total_bribe)} direct builder bribes` : "incl. priority tips"],
    ["Capital flash-borrowed", usd(a.flash_volume), "by measured arb txs"],
    ["Active arb bots", num(a.unique_bots), `${num(a.profitable_bots)} net-profitable`],
  ];
  $("#kpis").innerHTML = k.map(([t, v, s, c]) =>
    `<div class="kpi"><div class="k">${t}</div><div class="v ${c || ""}">${v}</div><div class="s">${s}</div></div>`).join("");
}

// ---------- charts ----------
function renderDaily(daily) {
  const labels = daily.map((d) => d.day.slice(5));
  draw("ch-daily-cat", {
    type: "bar",
    data: {
      labels,
      datasets: CAT_ORDER.map((c) => ({
        label: CAT[c].label, data: daily.map((d) => d.counts[c] || 0), backgroundColor: CAT[c].color,
        ...barBase, borderRadius: 0, borderColor: "#191919", borderWidth: { top: 2 }, stack: "s",
      })),
    },
    options: {
      interaction: { mode: "index", intersect: false },
      scales: { x: { stacked: true, grid: { display: false } }, y: { stacked: true, grid: { color: GRID }, border: { color: AXIS } } },
      plugins: { legend: { position: "bottom" },
        tooltip: { callbacks: { footer: (items) => "Total: " + num(items.reduce((s, i) => s + i.parsed.y, 0)) } } },
    },
  });
  draw("ch-daily-pnl", {
    type: "bar",
    data: {
      labels,
      datasets: [
        { label: "Profit (winning txs)", data: daily.map((d) => d.profit || 0), backgroundColor: PROFIT, ...barBase, stack: "p" },
        { label: "Loss (losing txs)", data: daily.map((d) => d.loss || 0), backgroundColor: LOSS, ...barBase, stack: "p" },
      ],
    },
    options: {
      interaction: { mode: "index", intersect: false },
      scales: { x: { stacked: true, grid: { display: false } },
        y: { stacked: true, grid: { color: GRID }, border: { color: AXIS }, ticks: { callback: (v) => usd(v) } } },
      plugins: { legend: { position: "bottom" },
        tooltip: { callbacks: {
          label: (i) => `${i.dataset.label}: ${usd(i.parsed.y, { plus: true })}`,
          footer: (items) => { const d = daily[items[0].dataIndex]; return `Net: ${usd(d.net, { plus: true })} · ${num(d.wins)}/${num(d.arbs)} profitable · gas ${usd(d.gas)}`; },
        } } },
    },
  });
}

function renderHist(h) {
  const total = h.reduce((s, b) => s + b.count, 0);
  draw("ch-hist", {
    type: "bar",
    data: { labels: h.map((b) => b.label), datasets: [{ label: "Txs", data: h.map((b) => b.count),
      backgroundColor: h.map((b) => b.positive ? PROFIT : LOSS), ...barBase, maxBarThickness: 40 }] },
    options: {
      scales: { x: { grid: { display: false } }, y: { grid: { color: GRID }, border: { color: AXIS } } },
      plugins: { legend: { display: false }, tooltip: { callbacks: {
        label: (i) => `${num(i.parsed.y)} txs (${pct(total ? i.parsed.y / total : 0)}) · sum ${usd(h[i.dataIndex].sum, { plus: true })}`,
      } } },
    },
  });
  const losing = h.filter((b) => !b.positive).reduce((s, b) => s + b.count, 0);
  const small = h.filter((b) => ["-$1…0", "$0…1"].includes(b.label)).reduce((s, b) => s + b.count, 0);
  $("#hist-note").textContent = total ? `${pct(losing / total)} of measured txs lost money after gas; ${pct(small / total)} landed within ±$1 — most of the action is razor-thin.` : "";
}

function renderConcentration(bots) {
  const pos = bots.filter((b) => b.net > 0).sort((x, y) => y.net - x.net);
  const total = pos.reduce((s, b) => s + b.net, 0);
  let acc = 0;
  const pts = pos.map((b, i) => { acc += b.net; return { x: i + 1, y: total ? (acc / total) * 100 : 0, bot: b.bot, net: b.net }; });
  draw("ch-conc", {
    type: "line",
    data: { datasets: [{ label: "Cumulative share of profit", data: pts, borderColor: PROFIT, backgroundColor: PROFIT,
      borderWidth: 2, pointRadius: pts.length > 40 ? 0 : 3, pointHoverRadius: 5, tension: 0.15 }] },
    options: {
      parsing: false,
      interaction: { mode: "nearest", intersect: false, axis: "x" },
      scales: { x: { type: "linear", min: 1, title: { display: true, text: "Bots ranked by net profit" }, grid: { display: false }, ticks: { precision: 0 } },
        y: { min: 0, max: 100, grid: { color: GRID }, border: { color: AXIS }, ticks: { callback: (v) => v + "%" } } },
      plugins: { legend: { display: false }, tooltip: { callbacks: {
        title: (i) => `Top ${i[0].raw.x} bot${i[0].raw.x > 1 ? "s" : ""}`,
        label: (i) => [`${i.raw.y.toFixed(1)}% of all profit`, `#${i.raw.x}: ${short(i.raw.bot)} ${usd(i.raw.net, { plus: true })}`],
      } } },
    },
  });
  const p = (k) => pts[Math.min(k, pts.length) - 1]?.y;
  $("#conc-note").textContent = pts.length ? `${pts.length} bots were net-profitable. Top 1 took ${p(1).toFixed(0)}%, top 3 took ${p(3).toFixed(0)}%, top 10 took ${p(10).toFixed(0)}% of all profit.` : "";
}

// ---------- tables ----------
function renderProviders(rows) {
  $("#tbl-prov tbody").innerHTML = rows.map((r) => `<tr>
    <td>${esc(r.provider)}</td><td class="r">${num(r.txs)}</td><td class="r">${usd(r.volume)}</td><td class="r">${usd(r.fees)}</td>
    <td class="r">${num(r.arb_count)}</td><td class="r">${r.arb_count ? pct(r.arb_wins / r.arb_count) : "—"}</td>
    <td class="r ${cls(r.arb_net)}">${usd(r.arb_net, { plus: true })}</td></tr>`).join("") || `<tr><td colspan="7" class="muted">No data yet</td></tr>`;
}
function renderVenues(rows) {
  $("#tbl-venue tbody").innerHTML = rows.map((r) => `<tr><td>${esc(r.venue)}</td><td class="r">${num(r.txs)}</td>
    <td class="r">${pct(r.txs ? r.wins / r.txs : 0)}</td><td class="r ${cls(r.net)}">${usd(r.net, { plus: true })}</td></tr>`).join("")
    || `<tr><td colspan="4" class="muted">No data yet</td></tr>`;
}
function renderTokens(rows) {
  $("#tokens").innerHTML = rows.map((t) => `<a class="chip" target="_blank" rel="noopener" href="${state.status.explorer_addr}${t.token}">
    <b>${esc(t.symbol)}</b> ${num(t.loans)} loans <span class="muted">(${num(t.arb_loans)} arb)</span></a>`).join("");
}
function renderBots(rows) {
  $("#tbl-bots tbody").innerHTML = rows.slice(0, 25).map((b, i) => `<tr class="click" data-bot="${b.bot}">
    <td>${i + 1}</td><td><a class="addr" target="_blank" rel="noopener" href="${state.status.explorer_addr}${b.bot}">${short(b.bot)}</a></td>
    <td class="r">${num(b.txs)}</td><td class="r">${pct(b.win_rate)}</td><td class="r">${usd(b.gross)}</td><td class="r">${usd(b.gas)}</td>
    <td class="r ${cls(b.net)}"><b>${usd(b.net, { plus: true })}</b></td><td class="r ${cls(b.net)}">${usd(b.net / b.txs, { plus: true })}</td>
    <td class="r">${usd(b.best, { plus: true })}</td><td class="r">${num(b.eoas)}</td><td>${ago(b.last_ts)}</td></tr>`).join("")
    || `<tr><td colspan="11" class="muted">No data yet</td></tr>`;
  document.querySelectorAll("#tbl-bots tr[data-bot]").forEach((tr) => tr.addEventListener("click", (e) => {
    if (e.target.closest("a")) return;
    state.bot = tr.dataset.bot; state.txCat = "arbitrage"; $("#tx-cat").value = "arbitrage"; state.txOffset = 0;
    loadTxs(); $("#tbl-tx").scrollIntoView({ behavior: "smooth", block: "start" });
  }));
}

function quality(r) {
  if (r.unpriced_tokens) return `<span class="q bad" title="Some tokens have no reliable USD price">partly priced</span>`;
  if (r.category === "arbitrage" && !r.reliable) return `<span class="q bad" title="Native ETH or profit destination not observable">unmeasured</span>`;
  return `<span class="q" title="ETH accounting mode">${esc(r.eth_mode)}</span>`;
}
async function loadTxs() {
  const params = { days: state.days, category: state.txCat, sort: state.txSort, limit: state.txLimit, offset: state.txOffset, reliable_only: false };
  if (state.bot) params.bot = state.bot;
  const d = await api("txs", params);
  $("#tx-total").textContent = `(${num(d.total)})`;
  const bf = $("#botfilter");
  if (state.bot) { bf.hidden = false; bf.innerHTML = `bot ${short(state.bot)} <button aria-label="clear">×</button>`;
    bf.querySelector("button").onclick = () => { state.bot = null; state.txOffset = 0; loadTxs(); }; }
  else bf.hidden = true;
  const ex = state.status.explorer_tx;
  $("#tbl-tx tbody").innerHTML = d.rows.map((r) => {
    const c = CAT[r.category] || { label: r.category, color: INK2 };
    const show = r.category === "arbitrage";
    return `<tr class="click" data-hash="${r.hash}">
      <td>${utc(r.ts)}</td>
      <td><a class="addr" target="_blank" rel="noopener" href="${ex}${r.hash}">${short(r.hash)}</a></td>
      <td class="addr">${short(r.to_addr)}</td>
      <td><span class="pill"><i style="background:${c.color}"></i>${c.label}</span></td>
      <td>${esc(r.providers)}</td><td class="r">${r.flash_usd ? usd(r.flash_usd) : "<span class='muted'>—</span>"}</td>
      <td title="${esc(r.venues)}">${r.n_swaps} <span class="muted">${esc((r.venues || "").split(",").slice(0, 2).join(", "))}${(r.venues || "").split(",").length > 2 ? "…" : ""}</span></td>
      <td class="r">${show ? usd(r.gross_usd, { plus: true }) : "<span class='muted'>n/a</span>"}</td><td class="r">${usd(r.gas_usd)}</td>
      <td class="r ${show ? cls(r.net_usd) : ""}">${show ? "<b>" + usd(r.net_usd, { plus: true }) + "</b>" : "<span class='muted'>n/a</span>"}</td>
      <td>${quality(r)}</td></tr>`;
  }).join("") || `<tr><td colspan="11" class="muted">No transactions</td></tr>`;
  document.querySelectorAll("#tbl-tx tr[data-hash]").forEach((tr) => tr.addEventListener("click", (e) => {
    if (!e.target.closest("a")) openTx(tr.dataset.hash);
  }));
  $("#pg-info").textContent = d.total ? `${num(state.txOffset + 1)}–${num(Math.min(state.txOffset + state.txLimit, d.total))} of ${num(d.total)}` : "";
  $("#pg-prev").disabled = state.txOffset === 0;
  $("#pg-next").disabled = state.txOffset + state.txLimit >= d.total;
}

async function openTx(hash) {
  const d = await api("tx/" + hash);
  const t = d.tx, ex = state.status;
  const c = CAT[t.category] || { label: t.category };
  const flows = d.flows.map((f) => `<tr><td>${esc(f.symbol || short(f.token))}</td><td class="r ${cls(f.amount)}">${f.amount === null ? "?" : (f.amount > 0 ? "+" : "") + Number(f.amount.toPrecision(6))}</td>
    <td class="r ${cls(f.usd)}">${usd(f.usd, { plus: true })}</td></tr>`).join("") || `<tr><td colspan="3" class="muted">No token reached the bot / EOA</td></tr>`;
  const loans = d.loans.map((l) => `<tr><td>${esc(l.provider)}</td><td>${esc(l.symbol || short(l.token))}</td><td class="r">${l.amount === null ? "?" : Number(l.amount.toPrecision(6)).toLocaleString()}</td><td class="r">${l.fee === null ? "?" : Number(l.fee.toPrecision(4))}</td></tr>`).join("");
  $("#drawer-body").innerHTML = `
    <h3>${c.label} transaction</h3>
    <a class="addr" target="_blank" rel="noopener" href="${ex.explorer_tx}${t.hash}">${t.hash}</a>
    <div class="kv">
      <div>Time (UTC)</div><div>${utc(t.ts)} · block ${num(t.block)}</div>
      <div>Bot EOA (tx.from)</div><div><a class="addr" target="_blank" rel="noopener" href="${ex.explorer_addr}${t.from_addr}">${t.from_addr}</a></div>
      <div>Bot contract (tx.to)</div><div><a class="addr" target="_blank" rel="noopener" href="${ex.explorer_addr}${t.to_addr}">${t.to_addr}</a></div>
      <div>Swaps</div><div>${t.n_swaps} swaps over ${t.n_pools} pools · ${esc(t.venues || "—")}</div>
      <div>Gross result</div><div class="${cls(t.gross_usd)}">${usd(t.gross_usd, { plus: true })}</div>
      <div>Gas fee</div><div>${usd(t.gas_usd)} (${(Number(t.gas_fee_wei) / 1e18).toPrecision(4)} ETH, ${num(t.gas_used)} gas)</div>
      ${t.bribe_usd ? `<div>Builder bribe (in trace)</div><div>${usd(t.bribe_usd)} (already inside gross)</div>` : ""}
      <div>Net after gas</div><div class="${cls(t.net_usd)}"><b>${usd(t.net_usd, { plus: true })}</b></div>
      <div>ETH accounting</div><div>${esc(t.eth_mode)}${t.reliable ? "" : " · <span class='q bad'>excluded from profit stats</span>"}</div>
    </div>
    <h4>Flash loans</h4>
    <table><thead><tr><th>Provider</th><th>Token</th><th class="r">Amount</th><th class="r">Fee</th></tr></thead><tbody>${loans}</tbody></table>
    <h4 style="margin-top:16px">Net token change for bot + EOA</h4>
    <table><thead><tr><th>Token</th><th class="r">Amount</th><th class="r">USD</th></tr></thead><tbody>${flows}</tbody></table>
    <p class="note">Borrowed principal cancels out (received and repaid in the same tx), so only the real gain/loss remains.</p>`;
  $("#drawer").hidden = false;
}

// ---------- orchestration ----------
async function loadAll() {
  const p = { days: state.days, reliable_only: state.reliable };
  try {
    await loadStatus();
    const [sum, daily, hist, prov, ven, bots, toks] = await Promise.all([
      api("summary", p), api("daily", p), api("histogram", p), api("providers", p), api("venues", p),
      api("bots", { ...p, limit: 200 }), api("tokens", { days: state.days }),
    ]);
    renderVerdict(sum); renderKpis(sum); renderDaily(daily); renderHist(hist); renderConcentration(bots);
    renderProviders(prov); renderVenues(ven); renderTokens(toks); renderBots(bots);
    await loadTxs();
  } catch (e) {
    console.error(e);
    $("#sync-text").textContent = "Waiting for indexer… (" + e.message + ")";
  }
}

function bind() {
  document.querySelectorAll("#range button").forEach((b) => b.addEventListener("click", () => {
    document.querySelectorAll("#range button").forEach((x) => x.classList.toggle("on", x === b));
    state.days = +b.dataset.days; state.txOffset = 0; loadAll();
  }));
  $("#reliable").addEventListener("change", (e) => { state.reliable = e.target.checked; loadAll(); });
  $("#tx-cat").addEventListener("change", (e) => { state.txCat = e.target.value; state.txOffset = 0; loadTxs(); });
  document.querySelectorAll("#tx-sort button").forEach((b) => b.addEventListener("click", () => {
    document.querySelectorAll("#tx-sort button").forEach((x) => x.classList.toggle("on", x === b));
    state.txSort = b.dataset.sort; state.txOffset = 0; loadTxs();
  }));
  $("#pg-prev").onclick = () => { state.txOffset = Math.max(0, state.txOffset - state.txLimit); loadTxs(); };
  $("#pg-next").onclick = () => { state.txOffset += state.txLimit; loadTxs(); };
  $("#drawer-close").onclick = () => { $("#drawer").hidden = true; };
  $("#drawer").addEventListener("click", (e) => { if (e.target.id === "drawer") $("#drawer").hidden = true; });
  document.addEventListener("keydown", (e) => { if (e.key === "Escape") $("#drawer").hidden = true; });
}

window.addEventListener("DOMContentLoaded", () => {
  setupChartDefaults(); bind(); loadAll();
  setInterval(loadAll, 120000);
  setInterval(() => loadStatus().catch(() => {}), 20000);
});
