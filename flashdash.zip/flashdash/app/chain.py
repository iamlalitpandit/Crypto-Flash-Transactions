"""On-chain constants for Ethereum mainnet.

Every topic hash below was computed with keccak256 over the canonical event
signature AND cross-checked against live mainnet logs (topic count + data word
count) on 2026-11-25. See README "Verification" section.
"""

# ---- Flash-loan providers -------------------------------------------------
AAVE_V3_POOL = "0x87870bca3f3fd6335c3f4ce8392d69350b4fa4e2"
AAVE_V2_POOL = "0x7d2768de32b0b80b7a3454c06bdac94a69ddc7a9"
BALANCER_V2_VAULT = "0xba12222222228d8ba445958a75a0704d566bf2c8"
MORPHO_BLUE = "0xbbbbbbbbbb9cc5e90e3b3af64bdaf62c37eeffcb"
MAKER_DSS_FLASH = "0x60744434d6339a6b27d73d9eda62b6f66a0a04fa"

# FlashLoan(address indexed target, address initiator, address indexed asset,
#           uint256 amount, uint8 interestRateMode, uint256 premium, uint16 indexed referralCode)
T_AAVE3_FLASH = "0xefefaba5e921573100900a3ad9cf29f222d995fb3b6045797eaea7521bd8d6f0"
# FlashLoan(address indexed target, address indexed initiator, address indexed asset,
#           uint256 amount, uint256 premium, uint16 referralCode)
T_AAVE2_FLASH = "0x631042c832b07452973831137f2d73e395028b44b250dedc5abb0ee766e168ac"
# Balancer: FlashLoan(address indexed recipient, address indexed token, uint256 amount, uint256 feeAmount)
# Maker:    FlashLoan(address indexed receiver, address token, uint256 amount, uint256 fee)
# (same canonical signature -> same topic; disambiguated by emitting address)
T_FLASHLOAN_4 = "0x0d7d75e01ab95780d3cd1c8ec0dd6c2ce19e3a20427eec8bf53283b6fb8e95f0"
# Morpho Blue: FlashLoan(address indexed caller, address indexed token, uint256 assets)
T_MORPHO_FLASH = "0xc76f1b4fe4396ac07a9fa55a415d4ca430e72651d37d3401f3bed7cb13fc4f12"
# Uniswap V3 pool: Flash(address indexed sender, address indexed recipient,
#                       uint256 amount0, uint256 amount1, uint256 paid0, uint256 paid1)
T_UNI3_FLASH = "0xbdbdb71d7860376ba52b25a5028beea23581364a40522f6bcfb86bb1f2dca633"

PROVIDER_ADDRESSES = [AAVE_V3_POOL, AAVE_V2_POOL, BALANCER_V2_VAULT, MORPHO_BLUE, MAKER_DSS_FLASH]
PROVIDER_TOPICS = [T_AAVE3_FLASH, T_AAVE2_FLASH, T_FLASHLOAN_4, T_MORPHO_FLASH]

PROVIDER_NAMES = {
    AAVE_V3_POOL: "Aave V3",
    AAVE_V2_POOL: "Aave V2",
    BALANCER_V2_VAULT: "Balancer V2",
    MORPHO_BLUE: "Morpho Blue",
    MAKER_DSS_FLASH: "Maker DssFlash",
}

# ---- DEX swap events --------------------------------------------------------
SWAP_TOPICS = {
    # Swap(address indexed sender, uint amount0In, uint amount1In, uint amount0Out, uint amount1Out, address indexed to)
    "0xd78ad95fa46c994b6551d0da85fc275fe613ce37657fb8d5e3d130840159d822": "UniV2-style",
    # Swap(address indexed sender, address indexed recipient, int256, int256, uint160, uint128, int24)
    "0xc42079f94a6350d7e6235f29174924f928cc2ac818eb64fed8004e115fbcca67": "UniV3-style",
    # PancakeSwap V3 Swap (+ protocolFeesToken0/1)
    "0x19b47279256b2a23a1665c810c8d55a1758940ee09377d4f8d26497a3577dc83": "PancakeV3",
    # Uniswap V4 PoolManager Swap(bytes32 indexed id, address indexed sender, int128, int128, uint160, uint128, int24, uint24)
    "0x40e9cecb9f5f1f1c5b9c97dec2917b7ee92e57ba5563708daca94dd84ad7112f": "UniV4",
    # Balancer V2 Vault Swap(bytes32 indexed poolId, address indexed tokenIn, address indexed tokenOut, uint256, uint256)
    "0x2170c741c41531aec20e7c107c24eecfdd15e69c9bb0a8dd37b1840b9e0b207b": "BalancerV2",
    # Curve TokenExchange / TokenExchangeUnderlying (stableswap, int128 ids)
    "0x8b3e96f2b889fa771c53c981b40daf005f63f637f1869f707052d15a3dd97140": "Curve",
    "0xd013ca23e77a65003c2c659c5442c00c805371b7fc1ebd4c206c41d1536bd90b": "Curve",
    # Curve crypto pools (uint256 ids, with/without fee+packed_price_scale)
    "0x143f1f8e861fbdeddd5b46e844b7d3ac7b86a122f36e8c463859ee6811b1f29c": "Curve",
    "0xb2e76ae99761dc136e598d4a629bb347eccb9532a5f8bbd72e18467c3c34cc98": "Curve",
}

# ---- Liquidation events (to separate liquidations from arbitrage) -----------
LIQUIDATION_TOPICS = {
    # Aave V2/V3 LiquidationCall(address indexed,address indexed,address indexed,uint256,uint256,address,bool)
    "0xe413a321e8681d831f4dbccbca790d2952b56f977908e45be37335533e005286": "Aave",
    # Morpho Blue Liquidate(bytes32 indexed id, address indexed caller, address indexed borrower, 5x uint256)
    "0xa4946ede45d0c6f06a0f5ce92c9ad3b4751452d2fe0e25010783bcab57a67e41": "Morpho",
    # Compound V2 LiquidateBorrow(address,address,uint256,address,uint256)
    "0x298637f684da70674f26509b10f07ec2fbc77a335ab1e7d6215a4b2484d8bb52": "CompoundV2",
}

# ---- Token accounting ---------------------------------------------------------
T_TRANSFER = "0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef"
T_WETH_DEPOSIT = "0xe1fffcc4923d04b559f4d29a8bfc6cda04eb5b0d3c460751c2402c5c5cc9109c"
T_WETH_WITHDRAWAL = "0x7fcf532c15f0a6db0bd6d0e038bea71d30d808c7d98cb3bf7268a95bf5081b65"
WETH = "0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2"
ETH_PSEUDO = "eth"  # native ETH key in flow maps

# 4-byte selectors for Uniswap V3 pool token lookups
SEL_TOKEN0 = "0x0dfe1681"
SEL_TOKEN1 = "0xd21220a7"
