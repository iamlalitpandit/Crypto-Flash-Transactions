"""Historical token prices from DefiLlama coins API (free, no key).

GET {PRICE_API}/prices/historical/{unix_ts}/ethereum:0xA,ethereum:0xB?searchWidth=6h
-> {"coins": {"ethereum:0x..": {"decimals": 18, "symbol": "WETH", "price": 3432.3, "timestamp": ..., "confidence": 0.99}}}
(response format verified live on 2026-11-25)
"""
from __future__ import annotations

import asyncio
import logging

import httpx

log = logging.getLogger("prices")


async def fetch_prices(client: httpx.AsyncClient, base: str, ts: int, tokens: list[str]) -> dict[str, dict]:
    out: dict[str, dict] = {}
    tokens = [t for t in tokens if t.startswith("0x") and len(t) == 42]
    for i in range(0, len(tokens), 60):
        chunk = tokens[i:i + 60]
        coins = ",".join(f"ethereum:{t}" for t in chunk)
        url = f"{base}/prices/historical/{ts}/{coins}"
        for attempt in range(4):
            try:
                r = await client.get(url, params={"searchWidth": "6h"}, timeout=40)
                if r.status_code == 429:
                    await asyncio.sleep(3 * (attempt + 1))
                    continue
                r.raise_for_status()
                for k, v in (r.json().get("coins") or {}).items():
                    out[k.split(":", 1)[1].lower()] = v
                break
            except Exception as e:  # noqa
                log.warning("price fetch failed (%s), attempt %d", e, attempt + 1)
                await asyncio.sleep(2 * (attempt + 1))
        await asyncio.sleep(0.3)
    return out
