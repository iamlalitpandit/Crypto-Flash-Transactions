from app import chain as C
from app.decode import analyze_receipt, classify, eth_flows_from_trace, is_reliable

BOT = "0x" + "b0" * 20
EOA = "0x" + "e0" * 20
POOL_A = "0x" + "a1" * 20
POOL_B = "0x" + "a2" * 20
USDC = "0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48"
MINER = "0x" + "c0" * 20


def t(addr):  # address -> 32-byte topic
    return "0x" + "0" * 24 + addr[2:]


def w(n):
    return format(n, "064x")


def transfer(token, frm, to, val, li):
    return {"address": token, "topics": [C.T_TRANSFER, t(frm), t(to)], "data": "0x" + w(val), "logIndex": hex(li)}


def receipt(logs, gas=200_000, gp=10 ** 9):
    return {"transactionHash": "0x" + "11" * 32, "blockNumber": hex(100), "from": EOA, "to": BOT,
            "status": "0x1", "gasUsed": hex(gas), "effectiveGasPrice": hex(gp), "logs": logs}


def morpho_flash(token, amount, li=0):
    return {"address": C.MORPHO_BLUE, "topics": [C.T_MORPHO_FLASH, t(BOT), t(token)], "data": "0x" + w(amount),
            "logIndex": hex(li)}


def uni3_swap(pool, li):
    return {"address": pool, "topics": [list(k for k, v in C.SWAP_TOPICS.items() if v == "UniV3-style")[0],
                                        t(BOT), t(BOT)], "data": "0x" + w(0) * 5, "logIndex": hex(li)}


def arb_logs(profit=5 * 10 ** 6):
    # borrow 1000 USDC from Morpho, USDC->WETH on A, WETH->USDC on B, repay 1000, keep profit
    return [
        morpho_flash(USDC, 1000 * 10 ** 6, 0),
        transfer(USDC, C.MORPHO_BLUE, BOT, 1000 * 10 ** 6, 1),
        transfer(USDC, BOT, POOL_A, 1000 * 10 ** 6, 2),
        transfer(C.WETH, POOL_A, BOT, 5 * 10 ** 17, 3),
        uni3_swap(POOL_A, 4),
        transfer(C.WETH, BOT, POOL_B, 5 * 10 ** 17, 5),
        transfer(USDC, POOL_B, BOT, 1000 * 10 ** 6 + profit, 6),
        uni3_swap(POOL_B, 7),
        transfer(USDC, BOT, C.MORPHO_BLUE, 1000 * 10 ** 6, 8),
    ]


def test_flashloan_decoding_all_providers():
    logs = [
        {"address": C.AAVE_V3_POOL, "topics": [C.T_AAVE3_FLASH, t(BOT), t(USDC), "0x" + w(0)],
         "data": "0x" + w(int(BOT, 16)) + w(500) + w(0) + w(3), "logIndex": "0x1"},
        {"address": C.BALANCER_V2_VAULT, "topics": [C.T_FLASHLOAN_4, t(BOT), t(C.WETH)],
         "data": "0x" + w(10 ** 18) + w(0), "logIndex": "0x2"},
        {"address": C.MAKER_DSS_FLASH, "topics": [C.T_FLASHLOAN_4, t(BOT)],
         "data": "0x" + w(int(USDC, 16)) + w(77) + w(0), "logIndex": "0x3"},
        morpho_flash(USDC, 42, 4),
        # Balancer topic emitted by an unknown address must be ignored
        {"address": POOL_A, "topics": [C.T_FLASHLOAN_4, t(BOT), t(USDC)], "data": "0x" + w(1) + w(0),
         "logIndex": "0x5"},
    ]
    fl = analyze_receipt(receipt(logs))["flashloans"]
    assert [f["provider"] for f in fl] == ["Aave V3", "Balancer V2", "Maker DssFlash", "Morpho Blue"]
    assert fl[0]["amount"] == 500 and fl[0]["fee"] == 3 and fl[0]["token"] == USDC
    assert fl[2]["token"] == USDC and fl[2]["amount"] == 77


def test_uni3_flash_uses_pool_tokens():
    lg = {"address": POOL_A, "topics": [C.T_UNI3_FLASH, t(BOT), t(BOT)],
          "data": "0x" + w(100) + w(0) + w(1) + w(0), "logIndex": "0x9"}
    fl = analyze_receipt(receipt([lg]), {POOL_A: (USDC, C.WETH)})["flashloans"]
    assert len(fl) == 1 and fl[0]["token"] == USDC and fl[0]["amount"] == 100 and fl[0]["fee"] == 1


def test_arbitrage_profit_flows():
    a = analyze_receipt(receipt(arb_logs()))
    assert a["n_swaps"] == 2 and a["n_pools"] == 2
    assert a["flows"] == {USDC: 5 * 10 ** 6}  # flash principal nets to zero
    assert a["gas_fee_wei"] == 200_000 * 10 ** 9
    assert classify(a["n_swaps"], a["n_pools"], [], {USDC: 5.0}, gross_usd=5, flash_usd=1000) == "arbitrage"


def test_internal_transfers_between_eoa_and_bot_ignored():
    logs = arb_logs() + [transfer(USDC, BOT, EOA, 5 * 10 ** 6, 20)]
    assert analyze_receipt(receipt(logs))["flows"] == {USDC: 5 * 10 ** 6}


def test_conservative_withdrawal_counts_as_outflow_and_deposit_neutral():
    logs = arb_logs() + [
        {"address": C.WETH, "topics": [C.T_WETH_WITHDRAWAL, t(BOT)], "data": "0x" + w(10 ** 15), "logIndex": "0x30"},
        {"address": C.WETH, "topics": [C.T_WETH_DEPOSIT, t(BOT)], "data": "0x" + w(10 ** 16), "logIndex": "0x31"},
    ]
    a = analyze_receipt(receipt(logs))
    assert a["eth_mode"] == "conservative"
    assert a["flows"][C.WETH] == -(10 ** 15)
    assert C.ETH_PSEUDO not in a["flows"]


def test_native_balance_mode_counts_wrap_unwrap_and_eth():
    logs = arb_logs() + [
        {"address": C.WETH, "topics": [C.T_WETH_WITHDRAWAL, t(BOT)], "data": "0x" + w(10 ** 15), "logIndex": "0x30"},
    ]
    # unwrap 0.001 WETH and pay 0.0008 ETH to builder -> native ETH delta +0.0002
    a = analyze_receipt(receipt(logs), native={"delta": 2 * 10 ** 14, "bribe": 0, "mode": "balance"})
    assert a["eth_mode"] == "balance"
    assert a["flows"][C.WETH] == -(10 ** 15)
    assert a["flows"][C.ETH_PSEUDO] == 2 * 10 ** 14


def test_debug_trace_eth_flows_and_bribe():
    tree = {"type": "CALL", "from": EOA, "to": BOT, "value": "0x0", "calls": [
        {"type": "CALL", "from": C.WETH, "to": BOT, "value": hex(10 ** 15)},
        {"type": "CALL", "from": BOT, "to": MINER, "value": hex(8 * 10 ** 14)},
        {"type": "DELEGATECALL", "from": BOT, "to": POOL_A, "value": hex(10 ** 18)},
        {"type": "CALL", "from": BOT, "to": POOL_B, "value": hex(10 ** 18), "error": "execution reverted"},
    ]}
    net, bribe = eth_flows_from_trace(tree, "debug", {EOA, BOT}, MINER)
    assert net == 10 ** 15 - 8 * 10 ** 14
    assert bribe == 8 * 10 ** 14


def test_parity_trace_eth_flows():
    frames = [
        {"type": "call", "action": {"from": EOA, "to": BOT, "value": "0x5", "callType": "call"}},
        {"type": "call", "action": {"from": BOT, "to": MINER, "value": hex(1000), "callType": "call"}},
        {"type": "call", "action": {"from": POOL_A, "to": BOT, "value": hex(3000), "callType": "call"}},
        {"type": "call", "action": {"from": BOT, "to": POOL_B, "value": hex(50), "callType": "delegatecall"}},
    ]
    net, bribe = eth_flows_from_trace(frames, "trace", {EOA, BOT}, MINER)
    assert net == 2000 and bribe == 1000


def test_classification_rules():
    assert classify(3, 2, ["Aave"], {}) == "liquidation"
    assert classify(0, 0, [], {}) == "no_swap"
    assert classify(1, 1, [], {USDC: 3.0}) == "single_swap"
    assert classify(2, 1, [], {USDC: 3.0}) == "single_swap"  # same pool twice
    assert classify(2, 2, [], {USDC: 3.0, "0xdai": -100.0}) == "position_mgmt"
    # ETH/WETH outflow = builder payment cost, still arbitrage
    assert classify(2, 2, [], {USDC: 3.0, C.WETH: -2.0}, gross_usd=1, flash_usd=1000) == "arbitrage"
    # capital moved in: +$6927 on a $13.5k loan -> not cyclic arb
    assert classify(8, 5, [], {USDC: 6927.0}, gross_usd=6927, flash_usd=13587) == "position_mgmt"
    # unpriced token sign still respected
    assert classify(2, 2, [], {USDC: float("inf"), "0xdai": -5.0}) == "position_mgmt"


def test_reliability():
    assert is_reliable("arbitrage", "balance", "UniV4", 0, -1)
    assert not is_reliable("arbitrage", "conservative", "UniV3-style,UniV4", 0, 0)
    assert not is_reliable("arbitrage", "conservative", "UniV3-style", 0, -5)
    assert is_reliable("arbitrage", "conservative", "UniV3-style", 0, 0)
    assert not is_reliable("arbitrage", "trace", "", 1, 0)
    assert not is_reliable("arbitrage", "conservative", "Curve,UniV3-style", 0, 0)
    assert not is_reliable("arbitrage", "balance", "UniV3-style", 0, 0, n_flows=0)
