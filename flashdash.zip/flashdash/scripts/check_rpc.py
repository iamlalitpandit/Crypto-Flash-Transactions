#!/usr/bin/env python3
"""Check whether an Ethereum RPC can power this dashboard.

usage: python3 scripts/check_rpc.py https://eth-mainnet.example/v2/KEY
Tests: head, 30-day-old eth_getLogs, getLogs span limit, batching, archive eth_getBalance,
trace_transaction / debug_traceTransaction, address-less log filter (Uniswap V3 Flash).
"""
import sys
import time

import httpx

MORPHO = "0xbbbbbbbbbb9cc5e90e3b3af64bdaf62c37eeffcb"
T_MORPHO = "0xc76f1b4fe4396ac07a9fa55a415d4ca430e72651d37d3401f3bed7cb13fc4f12"
T_UNI3 = "0xbdbdb71d7860376ba52b25a5028beea23581364a40522f6bcfb86bb1f2dca633"


def main(url):
    c = httpx.Client(timeout=60)

    def call(m, p):
        r = c.post(url, json={"jsonrpc": "2.0", "id": 1, "method": m, "params": p}).json()
        return r.get("result"), r.get("error")

    def ok(name, good, detail=""):
        print(f"[{'PASS' if good else 'FAIL'}] {name} {detail}")
        return good

    head, err = call("eth_blockNumber", [])
    if not ok("eth_blockNumber", head is not None, err or int(head, 16)):
        return
    head = int(head, 16)
    old = head - 31 * 7200
    span_ok = None
    for span in (5000, 2000, 1000, 500, 100, 10):
        res, err = call("eth_getLogs", [{"fromBlock": hex(old), "toBlock": hex(old + span - 1), "address": MORPHO,
                                         "topics": [T_MORPHO]}])
        if res is not None:
            span_ok = (span, res)
            break
    ok("30-day-old eth_getLogs (required)", span_ok is not None,
       f"max tested span={span_ok[0]} blocks, {len(span_ok[1])} logs -> set LOG_CHUNK={span_ok[0]}" if span_ok else str(err)[:160])
    sample = span_ok[1][0]["transactionHash"] if span_ok and span_ok[1] else None
    r = c.post(url, json=[{"jsonrpc": "2.0", "id": i, "method": "eth_blockNumber", "params": []} for i in range(5)]).json()
    ok("JSON-RPC batching (recommended)", isinstance(r, list) and len(r) == 5)
    bal, err = call("eth_getBalance", [MORPHO, hex(old)])
    ok("archive eth_getBalance (needed for exact native-ETH profit)", bal is not None, str(err or "")[:160])
    if sample:
        t1, e1 = call("trace_transaction", [sample])
        ok("trace_transaction (optional, best accuracy)", t1 is not None, str(e1 or "")[:120])
        t2, e2 = call("debug_traceTransaction", [sample, {"tracer": "callTracer"}])
        ok("debug_traceTransaction callTracer (optional)", t2 is not None, str(e2 or "")[:120])
    res, err = call("eth_getLogs", [{"fromBlock": hex(head - 50), "toBlock": hex(head), "topics": [T_UNI3]}])
    ok("address-less getLogs (optional, Uniswap V3 Flash)", res is not None, str(err or "")[:120])
    t = time.time()
    for _ in range(5):
        call("eth_blockNumber", [])
    print(f"latency ~{(time.time() - t) / 5 * 1000:.0f} ms/request")


if __name__ == "__main__":
    if len(sys.argv) != 2:
        sys.exit(__doc__)
    main(sys.argv[1])
