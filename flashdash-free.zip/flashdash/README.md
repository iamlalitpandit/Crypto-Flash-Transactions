# Flash-Loan DEX Arbitrage Monitor

Self-hosted dashboard that indexes every **flash-loan funded transaction on Ethereum mainnet** for the
last `LOOKBACK_DAYS` (default 7, then follows the chain live), decodes what the borrowed money was used for, and measures
whether DEX-to-DEX arbitrage with flash loans is **actually profitable after gas**.

```
Ethereum RPC ──► indexer (Python) ──► SQLite (/data) ──► FastAPI (read-only) ──► Caddy (HTTPS) ──► browser
                     ▲
              DefiLlama prices
```

| What you get | |
|---|---|
| Verdict panel | win rate after gas, median & total net, profit concentration, gas share, edge in bps |
| KPIs | flash-loan txs, measured arbitrage txs, win rate, net profit, gas, capital borrowed, bots |
| Charts | daily txs by category · daily profit vs loss · net-profit distribution · profit concentration curve |
| Tables | providers (volume, fees, arb win rate) · DEX venues · top borrowed tokens · bot leaderboard |
| Explorer | paginated tx table (sort by recent / profit / loss / loan size), per-tx drawer with token-level P&L |

---

## 1. Requirements (all free)

* Linux VM with Docker + Docker Compose plugin. 1 vCPU / 1 GB RAM is enough; < 1 GB disk.
* Ports **80 and 443** open (Caddy gets a free Let's Encrypt certificate automatically).
* DNS **A record**: `dashboard.lalitpandit.online → <VM public IP>`.
* RPC: **no paid plan needed** — see §3.

## 2. Deploy

```bash
sudo apt-get update && sudo apt-get install -y docker.io docker-compose-v2 unzip   # skip if installed
unzip flashdash.zip && cd flashdash
cp .env.example .env
nano .env                       # ACME_EMAIL; optionally ARCHIVE_RPC_URL (free Infura key)
docker compose up -d --build
docker compose logs -f indexer
```

Open **https://dashboard.lalitpandit.online**. Firewall (ufw): `sudo ufw allow 80,443/tcp && sudo ufw allow 443/udp`.

The indexer works **live-first**: it starts at the current block (dashboard shows real data within a minute),
then fills history **backwards** in slices, re-checking the chain head between slices.

Optional password: `docker compose run --rm caddy caddy hash-password`, paste into the `basic_auth`
block in `Caddyfile`, `docker compose restart caddy`.

## 3. Free RPC setup — two options

| | Option A: zero signup | Option B: + free Infura key (recommended) |
|---|---|---|
| `.env` | `RPC_URL=https://ethereum-rpc.publicnode.com`, `ARCHIVE_RPC_URL=` empty | same `RPC_URL`, `ARCHIVE_RPC_URL=https://mainnet.infura.io/v3/<key>` |
| Live data | ✅ exact (balance-diff ETH accounting works near head) | ✅ same (live never spends Infura credits) |
| History on day 1 | ~1.4 days (publicnode keeps ~10k blocks of logs; older txs mostly "unmeasured") | fills ~1.5 days of history per day of free quota (estimate) |
| 7 days of data | after 7 days of running | after ~4–5 days (estimate) |

Why not other free tiers: Alchemy Free limits `eth_getLogs` to a **10-block** range on Ethereum (Alchemy docs),
which makes a backfill impractical. Infura's free Core plan includes Ethereum archive data with
3,000,000 credits/day and 500 credits/s; costs used here: `eth_getLogs` 255, receipt/balance/nonce 80
(Infura credit-cost table, checked 2026-11-25). ⚠️ Free plans change — re-check before relying on them.

How the free quota is protected:
* `DAILY_CREDIT_BUDGET` — the indexer counts credits itself and stops **history only** at the budget
  (also reacts to HTTP 402 "daily credit limit"). Live data keeps flowing via publicnode. Resumes 00:05 UTC.
* `CREDITS_PER_SEC` — weighted throttle so batches never exceed the per-second limit.
* `NATIVE_ONLY_WHEN_NEEDED` — the expensive native-ETH balance check (6 calls) runs only for arbitrage
  txs that touched Uniswap V4 / Curve, unwrapped WETH, or showed no observable result.

Check any RPC with `python3 scripts/check_rpc.py <url>` (needs `pip install httpx`).

Measured on 2026-11-25: ~490 flash-loan txs per 1,000 blocks (~3,500/day). History cost measured
~390k credits/day without balance checks; with balance checks it is estimated ~1.7M credits/day.

## 4. How the numbers are computed

1. **Discovery** – `eth_getLogs` for FlashLoan events: Aave V3 Pool `0x8787…4E2`, Aave V2 `0x7d27…7A9`,
   Balancer V2 Vault `0xBA12…2C8`, Morpho Blue `0xBBBB…FFCb`, Maker DssFlash `0x6074…04FA`, and
   (optional) every Uniswap V3 pool's `Flash` event.
2. **Decode** – each receipt: swap events (Uniswap V2/V3/V4 & forks, PancakeSwap V3, Balancer V2, Curve),
   liquidation events (Aave, Morpho, Compound V2), ERC-20 `Transfer`, WETH `Deposit`/`Withdrawal`.
3. **Beneficiary P&L** – net token change of `tx.from` (bot EOA) + `tx.to` (bot contract). Loan principal
   cancels out; provider fees reduce it. Native ETH via call trace → archive balance diff over the block
   (gas added back; skipped if the EOA sent >1 tx in that block) → otherwise "conservative".
4. **USD** – DefiLlama historical price at 12:00 UTC of the tx's day (`confidence ≥ 0.9`), WETH price for
   ETH and gas. `net = gross − gasUsed × effectiveGasPrice`.
5. **Category** – liquidation › no_swap › single_swap › position_mgmt › arbitrage (≥2 swaps on ≥2 pools,
   one-sided token result, |gross| ≤ 5% of loan). Rules live in `app/decode.py::classify`.
6. **Reliable** – profit stats use only txs with all tokens priced, observable native ETH and a non-empty
   result. Toggle "Reliable measurements only" off to include everything.

### Limits — read before drawing conclusions
* **Survivorship bias**: reverted attempts emit no flash-loan event; private-bundle losers never land.
* Profit forwarded to a third wallet in the same tx, or hedged on a CEX, is not visible.
* Swap venues outside the list (e.g. Fluid, Ekubo, Maverick) are not counted as swaps, but their token
  transfers are still included in P&L.
* Classification is heuristic; the per-tx drawer shows the raw token deltas so you can audit any row.

### Verification log (2026-11-25)
Every event topic in `app/chain.py` was computed as keccak256 of the canonical signature and checked
against live mainnet logs (topic count + data word count): Aave V3 FlashLoan (4 topics / 4 words),
Balancer V2 FlashLoan (3/2), Morpho Blue FlashLoan (3/1), Aave LiquidationCall (4/4), Morpho Liquidate (4/5).
Aave V2 emitted 0 flash loans in the last ~9.5k blocks (deprecated, kept for completeness).
DefiLlama `/prices/historical/{ts}/{coins}` response shape verified live.

## 5. Operations

```bash
docker compose ps                         # health
docker compose logs --tail 50 indexer     # progress / RPC errors
docker compose restart indexer            # after editing .env
docker compose down && docker compose up -d --build   # after code changes
docker compose exec api python -c "import urllib.request;print(urllib.request.urlopen('http://127.0.0.1:8000/healthz').read())"
```

Re-index from scratch (e.g. after changing classification rules):
`docker compose down && docker volume rm flashdash_flashdata && docker compose up -d`
(volume name = `<folder>_flashdata`; check with `docker volume ls`).

Re-price only (keeps receipts):
`docker compose exec indexer python -c "import sqlite3;c=sqlite3.connect('/data/flashdash.db');c.execute('UPDATE txs SET priced_at=NULL');c.commit()"`

API docs: `https://dashboard.lalitpandit.online/api/docs`.

## 6. Development

```bash
pip install -r requirements.txt pytest
python -m pytest tests            # decode / ETH accounting / classification unit tests
RPC_URL=... DB_PATH=./dev.db LOOKBACK_DAYS=0.1 python -m app.indexer
DB_PATH=./dev.db uvicorn app.api:app --reload
```
