"""Read-only FastAPI over the indexer's SQLite DB + static dashboard."""
from __future__ import annotations

import os
import statistics
import time
from datetime import datetime, timezone
from pathlib import Path

from fastapi import FastAPI, HTTPException, Query
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles

from . import chain as C
from . import config as cfg
from . import db

app = FastAPI(title="Flash-Loan DEX Arbitrage Monitor", docs_url="/api/docs", openapi_url="/api/openapi.json")
STATIC = Path(__file__).parent / "static"
CATEGORIES = ["arbitrage", "liquidation", "position_mgmt", "single_swap", "no_swap"]


def conn():
    if not os.path.exists(cfg.DB_PATH):
        raise HTTPException(503, "database not created yet - indexer starting")
    return db.connect(cfg.DB_PATH, readonly=True)


def window(days: int) -> int:
    return int(time.time()) - days * 86400


def where(days: int, category: str | None, reliable_only: bool, alias: str = "") -> tuple[str, list]:
    a = alias + "." if alias else ""
    w = [f"{a}ts >= ?", f"{a}priced_at IS NOT NULL"]
    p: list = [window(days)]
    if category and category != "all":
        w.append(f"{a}category = ?")
        p.append(category)
    if reliable_only:
        w.append(f"{a}reliable = 1")
    return " AND ".join(w), p


def pct(vals, q):
    if not vals:
        return None
    vals = sorted(vals)
    k = (len(vals) - 1) * q
    f = int(k)
    c = min(f + 1, len(vals) - 1)
    return vals[f] + (vals[c] - vals[f]) * (k - f)


@app.get("/api/status")
def status():
    c = conn()
    m = {r[0]: r[1] for r in c.execute("SELECT key, value FROM meta")}
    target = int(m.get("backfill_target", 0) or 0)
    back = int(m.get("back_cursor", 0) or 0)
    live = int(m.get("live_cursor", 0) or 0)
    head = int(m.get("head", 0) or live)
    floor = int(m.get("history_floor", 0) or 0)
    if m.get("backfill_done") == "1":
        prog = 1.0
    else:
        prog = (live - back) / (live - target) if live > target else 0
    counts = c.execute("SELECT COUNT(*), SUM(priced_at IS NOT NULL), MIN(ts), MAX(ts) FROM txs").fetchone()
    pending = c.execute("SELECT COUNT(*) FROM pending").fetchone()[0]
    modes = {r[0]: r[1] for r in c.execute(
        "SELECT eth_mode, COUNT(*) FROM txs WHERE category='arbitrage' GROUP BY 1")}
    return dict(
        chain=cfg.CHAIN_LABEL, status=m.get("status", "starting"), progress=round(max(0, min(1, prog)), 4),
        head=head, live_cursor=live, back_cursor=back, backfill_target=target, history_floor=floor or None,
        history_limited=bool(floor), archive=m.get("archive") == "1",
        quota_until=int(m.get("quota_until", 0) or 0), credits_today=int(m.get("credits_today", 0) or 0),
        daily_budget=cfg.DAILY_CREDIT_BUDGET, updated_at=int(m.get("updated_at", 0) or 0), txs=counts[0] or 0,
        priced=counts[1] or 0, pending=pending, first_ts=counts[2], last_ts=counts[3],
        trace_mode=m.get("trace_mode", "unresolved"), uni3_flash=m.get("uni3_disabled") != "1",
        arb_eth_modes=modes, last_error=m.get("last_error"), lookback_days=cfg.LOOKBACK_DAYS,
        explorer_tx=cfg.EXPLORER_TX, explorer_addr=cfg.EXPLORER_ADDR, server_time=int(time.time()),
    )


@app.get("/api/summary")
def summary(days: int = Query(30, ge=1, le=60), reliable_only: bool = True):
    c = conn()
    since = window(days)
    by_cat = {r[0]: dict(count=r[1], flash_usd=r[2] or 0, fee_usd=r[3] or 0, gas_usd=r[4] or 0)
              for r in c.execute("""SELECT category, COUNT(*), SUM(flash_usd), SUM(fee_usd), SUM(gas_usd)
                                    FROM txs WHERE ts>=? AND priced_at IS NOT NULL GROUP BY 1""", (since,))}
    total_all = sum(v["count"] for v in by_cat.values())
    w, p = where(days, "arbitrage", reliable_only)
    rows = c.execute(f"SELECT net_usd, gross_usd, gas_usd, bribe_usd, flash_usd, to_addr FROM txs WHERE {w}", p).fetchall()
    arb_all = c.execute("SELECT COUNT(*) FROM txs WHERE ts>=? AND category='arbitrage' AND priced_at IS NOT NULL",
                        (since,)).fetchone()[0]
    nets = [r[0] for r in rows]
    n = len(nets)
    wins = [x for x in nets if x > 0]
    bots = {}
    for r in rows:
        bots.setdefault(r[5], 0.0)
        bots[r[5]] += r[0]
    total_net = sum(nets)
    pos_total = sum(wins)
    top5 = sum(sorted([v for v in bots.values() if v > 0], reverse=True)[:5])
    gross = sum(r[1] for r in rows)
    gas = sum(r[2] for r in rows)
    return dict(
        days=days, reliable_only=reliable_only, total_flash_txs=total_all, by_category=by_cat,
        arb=dict(
            count=n, count_all=arb_all, excluded_unreliable=arb_all - n,
            wins=len(wins), win_rate=(len(wins) / n) if n else None,
            total_net=total_net, total_gross=gross, total_gas=gas,
            total_bribe=sum((r[3] or 0) for r in rows),
            gas_share_of_gross=(gas / gross) if gross > 0 else None,
            median_net=statistics.median(nets) if nets else None,
            mean_net=(total_net / n) if n else None,
            p10=pct(nets, 0.10), p90=pct(nets, 0.90), p99=pct(nets, 0.99),
            max_net=max(nets) if nets else None, min_net=min(nets) if nets else None,
            flash_volume=sum((r[4] or 0) for r in rows),
            unique_bots=len(bots),
            profitable_bots=sum(1 for v in bots.values() if v > 0),
            top5_share=(top5 / pos_total) if pos_total > 0 else None,
            above_100=sum(1 for x in nets if x >= 100),
            above_1000=sum(1 for x in nets if x >= 1000),
        ),
    )


@app.get("/api/daily")
def daily(days: int = Query(30, ge=1, le=60), reliable_only: bool = True):
    c = conn()
    since = window(days)
    out: dict[str, dict] = {}
    for r in c.execute("""SELECT day, category, COUNT(*) FROM txs WHERE ts>=? AND priced_at IS NOT NULL
                          GROUP BY 1,2 ORDER BY 1""", (since,)):
        out.setdefault(r[0], dict(day=r[0], counts={}, profit=0.0, loss=0.0, net=0.0, gas=0.0, arbs=0, wins=0))
        out[r[0]]["counts"][r[1]] = r[2]
    w, p = where(days, "arbitrage", reliable_only)
    for r in c.execute(f"""SELECT day, SUM(CASE WHEN net_usd>0 THEN net_usd ELSE 0 END),
                           SUM(CASE WHEN net_usd<0 THEN net_usd ELSE 0 END), SUM(net_usd), SUM(gas_usd), COUNT(*),
                           SUM(net_usd>0) FROM txs WHERE {w} GROUP BY 1""", p):
        d = out.setdefault(r[0], dict(day=r[0], counts={}))
        d.update(profit=r[1] or 0, loss=r[2] or 0, net=r[3] or 0, gas=r[4] or 0, arbs=r[5], wins=r[6] or 0)
    return sorted(out.values(), key=lambda x: x["day"])


BUCKETS = [(-1e18, -100, "< -$100"), (-100, -10, "-$100…-10"), (-10, -1, "-$10…-1"), (-1, 0, "-$1…0"),
           (0, 1, "$0…1"), (1, 10, "$1…10"), (10, 100, "$10…100"), (100, 1000, "$100…1k"),
           (1000, 1e18, "> $1k")]


@app.get("/api/histogram")
def histogram(days: int = Query(30, ge=1, le=60), reliable_only: bool = True):
    c = conn()
    w, p = where(days, "arbitrage", reliable_only)
    nets = [r[0] for r in c.execute(f"SELECT net_usd FROM txs WHERE {w}", p)]
    res = []
    for lo, hi, label in BUCKETS:
        sel = [x for x in nets if lo <= x < hi]
        res.append(dict(label=label, count=len(sel), sum=sum(sel), positive=lo >= 0))
    return res


@app.get("/api/providers")
def providers(days: int = Query(30, ge=1, le=60), reliable_only: bool = True):
    c = conn()
    since = window(days)
    rows = c.execute("""SELECT f.provider, COUNT(DISTINCT f.hash), t.category
                        FROM flashloans f JOIN txs t ON t.hash=f.hash
                        WHERE t.ts>=? AND t.priced_at IS NOT NULL GROUP BY 1,3""", (since,)).fetchall()
    out: dict[str, dict] = {}
    for prov, n, cat in rows:
        d = out.setdefault(prov, dict(provider=prov, txs=0, by_category={}, arb_net=0.0, arb_count=0, arb_wins=0,
                                      volume=0.0, fees=0.0))
        d["txs"] += n
        d["by_category"][cat] = n
    tok_dec = {r[0]: r[1] for r in c.execute("SELECT token, decimals FROM tokens")}
    prices = {(r[0], r[1]): r[2] for r in c.execute("SELECT day, token, price FROM prices WHERE price IS NOT NULL")}
    for prov, tok, amt, fee, day in c.execute("""SELECT f.provider, f.token, f.amount, f.fee, t.day FROM flashloans f
                                                 JOIN txs t ON t.hash=f.hash WHERE t.ts>=?""", (since,)):
        pr, dd = prices.get((day, tok)), tok_dec.get(tok)
        if pr is not None and dd is not None and prov in out:
            out[prov]["volume"] += int(amt) / 10 ** dd * pr
            out[prov]["fees"] += int(fee) / 10 ** dd * pr
    w, p = where(days, "arbitrage", reliable_only, "t")
    for prov, n, s, wins in c.execute(f"""SELECT f.provider, COUNT(DISTINCT t.hash), SUM(t.net_usd), SUM(t.net_usd>0)
                                         FROM txs t JOIN (SELECT DISTINCT hash, provider FROM flashloans) f
                                         ON f.hash=t.hash WHERE {w} GROUP BY 1""", p):
        if prov in out:
            out[prov].update(arb_count=n, arb_net=s or 0, arb_wins=wins or 0)
    return sorted(out.values(), key=lambda x: -x["txs"])


@app.get("/api/venues")
def venues(days: int = Query(30, ge=1, le=60), reliable_only: bool = True):
    c = conn()
    w, p = where(days, "arbitrage", reliable_only)
    agg: dict[str, dict] = {}
    for v, net in c.execute(f"SELECT venues, net_usd FROM txs WHERE {w}", p):
        for name in (v or "").split(","):
            if not name:
                continue
            d = agg.setdefault(name, dict(venue=name, txs=0, net=0.0, wins=0))
            d["txs"] += 1
            d["net"] += net
            d["wins"] += net > 0
    return sorted(agg.values(), key=lambda x: -x["txs"])


@app.get("/api/bots")
def bots(days: int = Query(30, ge=1, le=60), reliable_only: bool = True, limit: int = Query(25, le=200)):
    c = conn()
    w, p = where(days, "arbitrage", reliable_only)
    rows = c.execute(f"""SELECT to_addr, COUNT(*), SUM(net_usd), SUM(gross_usd), SUM(gas_usd), SUM(net_usd>0),
                         COUNT(DISTINCT from_addr), MAX(net_usd), MIN(net_usd), MAX(ts), SUM(flash_usd)
                         FROM txs WHERE {w} GROUP BY 1 ORDER BY 3 DESC LIMIT ?""", p + [limit]).fetchall()
    return [dict(bot=r[0], txs=r[1], net=r[2], gross=r[3], gas=r[4], wins=r[5], win_rate=r[5] / r[1] if r[1] else 0,
                 eoas=r[6], best=r[7], worst=r[8], last_ts=r[9], flash_volume=r[10] or 0) for r in rows]


@app.get("/api/tokens")
def tokens(days: int = Query(30, ge=1, le=60), limit: int = 12):
    c = conn()
    since = window(days)
    sym = {r[0]: r[1] for r in c.execute("SELECT token, symbol FROM tokens")}
    rows = c.execute("""SELECT f.token, COUNT(*), SUM(t.category='arbitrage') FROM flashloans f
                        JOIN txs t ON t.hash=f.hash WHERE t.ts>=? GROUP BY 1 ORDER BY 2 DESC LIMIT ?""",
                     (since, limit)).fetchall()
    return [dict(token=r[0], symbol=sym.get(r[0]) or (r[0][:8] + "…"), loans=r[1], arb_loans=r[2] or 0) for r in rows]


@app.get("/api/txs")
def txs(days: int = Query(30, ge=1, le=60), category: str = "arbitrage", reliable_only: bool = False,
        sort: str = "recent", limit: int = Query(50, le=500), offset: int = 0, bot: str | None = None):
    c = conn()
    w, p = where(days, category, reliable_only)
    if bot:
        w += " AND to_addr = ?"
        p.append(bot.lower())
    order = {"recent": "ts DESC", "profit": "net_usd DESC", "loss": "net_usd ASC",
             "volume": "flash_usd DESC", "gas": "gas_usd DESC"}.get(sort, "ts DESC")
    total = c.execute(f"SELECT COUNT(*) FROM txs WHERE {w}", p).fetchone()[0]
    rows = c.execute(f"""SELECT hash, block, ts, from_addr, to_addr, category, providers, venues, n_swaps, n_pools,
                         gross_usd, gas_usd, bribe_usd, net_usd, flash_usd, fee_usd, eth_mode, reliable, unpriced_tokens
                         FROM txs WHERE {w} ORDER BY {order} LIMIT ? OFFSET ?""", p + [limit, offset]).fetchall()
    return dict(total=total, rows=[dict(r) for r in rows])


@app.get("/api/tx/{h}")
def tx_detail(h: str):
    c = conn()
    t = c.execute("SELECT * FROM txs WHERE hash=?", (h.lower(),)).fetchone()
    if not t:
        raise HTTPException(404, "not found")
    day = t["day"]
    flows = []
    for tok, delta in c.execute("SELECT token, delta FROM flows WHERE hash=?", (t["hash"],)):
        key = C.WETH if tok == C.ETH_PSEUDO else tok
        info = c.execute("SELECT symbol, decimals FROM tokens WHERE token=?", (key,)).fetchone()
        pr = c.execute("SELECT price FROM prices WHERE day=? AND token=?", (day, key)).fetchone()
        dec = 18 if tok == C.ETH_PSEUDO else (info["decimals"] if info else None)
        amt = int(delta) / 10 ** dec if dec is not None else None
        flows.append(dict(token=tok, symbol="ETH" if tok == C.ETH_PSEUDO else (info["symbol"] if info else None),
                          amount=amt, usd=(amt * pr[0]) if (amt is not None and pr and pr[0] is not None) else None))
    loans = []
    for r in c.execute("SELECT provider, token, amount, fee FROM flashloans WHERE hash=? ORDER BY log_index", (t["hash"],)):
        info = c.execute("SELECT symbol, decimals FROM tokens WHERE token=?", (r[1],)).fetchone()
        dec = info["decimals"] if info else None
        loans.append(dict(provider=r[0], token=r[1], symbol=info["symbol"] if info else None,
                          amount=int(r[2]) / 10 ** dec if dec is not None else None,
                          fee=int(r[3]) / 10 ** dec if dec is not None else None))
    return dict(tx=dict(t), flows=flows, loans=loans)


@app.get("/healthz")
def healthz():
    try:
        s = status()
        stale = s["status"] != "quota_wait" and s["updated_at"] and time.time() - s["updated_at"] > 1800
        return JSONResponse({"ok": not stale, "updated_at": s["updated_at"]}, status_code=200 if not stale else 503)
    except HTTPException as e:
        return JSONResponse({"ok": False, "detail": e.detail}, status_code=503)


app.mount("/static", StaticFiles(directory=STATIC), name="static")


@app.get("/")
def index():
    return FileResponse(STATIC / "index.html", headers={"Cache-Control": "no-cache"})
