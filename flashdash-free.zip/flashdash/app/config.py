import os


def _b(name: str, default: str) -> bool:
    return os.getenv(name, default).strip().lower() in ("1", "true", "yes", "on")


# Live RPC (near chain head). A free public endpoint works here.
RPC_URL = os.getenv("RPC_URL", "https://ethereum-rpc.publicnode.com").strip()
# Optional archive RPC used ONLY for history backfill (e.g. Infura free key). Empty = use RPC_URL.
ARCHIVE_RPC_URL = os.getenv("ARCHIVE_RPC_URL", "").strip()
DB_PATH = os.getenv("DB_PATH", "/data/flashdash.db")
LOOKBACK_DAYS = float(os.getenv("LOOKBACK_DAYS", "7"))
CONFIRMATIONS = int(os.getenv("CONFIRMATIONS", "6"))
POLL_SECONDS = int(os.getenv("POLL_SECONDS", "60"))

# eth_getLogs block span. Adaptive: halves on "range too large" errors, grows back on success.
LOG_CHUNK = int(os.getenv("LOG_CHUNK", "2000"))
LOG_CHUNK_MAX = int(os.getenv("LOG_CHUNK_MAX", "5000"))
# Uniswap V3 Flash needs an address-less getLogs filter; many RPCs refuse it (auto-disabled on error)
ENABLE_UNIV3_FLASH = _b("ENABLE_UNIV3_FLASH", "true")

RECEIPT_BATCH = int(os.getenv("RECEIPT_BATCH", "25"))
CONCURRENCY = int(os.getenv("CONCURRENCY", "4"))
MAX_RPS = float(os.getenv("MAX_RPS", "20"))  # HTTP requests per second cap (a batch counts as 1)

# auto | trace | debug | off   -> exact native-ETH flows & builder bribes when RPC supports it
TRACE_MODE = os.getenv("TRACE_MODE", "auto").strip().lower()

PRICE_API = os.getenv("PRICE_API", "https://coins.llama.fi")
MIN_PRICE_CONFIDENCE = float(os.getenv("MIN_PRICE_CONFIDENCE", "0.9"))
# per-token-delta guard: a single token delta worth more than this is treated as unpriced (bad price feed)
MAX_TOKEN_DELTA_USD = float(os.getenv("MAX_TOKEN_DELTA_USD", "5000000"))

CHAIN_LABEL = os.getenv("CHAIN_LABEL", "Ethereum Mainnet")
EXPLORER_TX = os.getenv("EXPLORER_TX", "https://etherscan.io/tx/")
EXPLORER_ADDR = os.getenv("EXPLORER_ADDR", "https://etherscan.io/address/")

# arbitrage sanity bound: |gross result| above this fraction of flash-loan volume => not a cyclic arb
ARB_MAX_MARGIN = float(os.getenv("ARB_MAX_MARGIN", "0.05"))

# ---- free-tier controls ----
# Stop for the day (resume 00:05 UTC) once this many provider credits were spent. 0 = unlimited.
DAILY_CREDIT_BUDGET = int(os.getenv("DAILY_CREDIT_BUDGET", "0"))
# Credit-based per-second throttle (Infura free: 500 credits/s). 0 = off (MAX_RPS still applies).
CREDITS_PER_SEC = float(os.getenv("CREDITS_PER_SEC", "0"))
# Max seconds spent on history backfill before checking the chain head again
BACKFILL_SLICE_SECONDS = int(os.getenv("BACKFILL_SLICE_SECONDS", "120"))
# only look up native ETH for arb candidates that can involve it (saves ~60% of credits)
NATIVE_ONLY_WHEN_NEEDED = _b("NATIVE_ONLY_WHEN_NEEDED", "true")
