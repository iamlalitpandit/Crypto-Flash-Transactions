"""Indexer worker: backfill last N days of flash-loan txs, then follow the chain head.

Pipeline per block window:
  1. eth_getLogs for FlashLoan events (Aave V3/V2, Balancer V2, Morpho Blue, Maker, optional Uniswap V3 Flash)
  2. eth_getTransactionReceipt (batched) for each unique tx -> decode swaps, token flows, gas
  3. optional call trace for arbitrage candidates -> exact native ETH flows + builder bribes
  4. DefiLlama historical prices per UTC day -> USD gross / gas / net, classification
"""
from __future__ import annotations

import asyncio
import json
import logging
import math
import time
from datetime import datetime, timezone

import httpx

from . import chain as C
from . import config as cfg
from . import db
from .decode import analyze_receipt, classify, eth_flows_from_trace, is_reliable
from .prices import fetch_prices
from .rpc import LogScanner, QuotaExceeded, Rpc, RpcError, is_history_error

log = logging.getLogger("indexer")
WINDOW = 1500  # blocks per pipeline step (~5h) so the dashboard fills progressively


def day_of(ts: int) -> str:
    return datetime.fromtimestamp(ts, tz=timezone.utc).strftime("%Y-%m-%d")


class Indexer:
    def __init__(self):
        if not cfg.RPC_URL:
            raise SystemExit("RPC_URL is not set (see README)")
        self.conn = db.connect(cfg.DB_PATH)
        if cfg.ARCHIVE_RPC_URL:
            # live RPC = free public node (no credit budget); archive RPC = metered key used for history only
            self.rpc_live = Rpc(cfg.RPC_URL, rps=cfg.MAX_RPS)
            self.rpc_hist = Rpc(cfg.ARCHIVE_RPC_URL, rps=cfg.MAX_RPS, credits_per_sec=cfg.CREDITS_PER_SEC,
                                daily_budget=cfg.DAILY_CREDIT_BUDGET)
        else:
            self.rpc_live = self.rpc_hist = Rpc(cfg.RPC_URL, rps=cfg.MAX_RPS, credits_per_sec=cfg.CREDITS_PER_SEC,
                                                daily_budget=cfg.DAILY_CREDIT_BUDGET)
        self.rpc = self.rpc_live
        if db.get_meta(self.conn, "credit_day") == self.rpc_hist.credit_day:
            self.rpc_hist.credits_today = int(db.get_meta(self.conn, "credits_today", 0))
        self.head = 0
        self.archive = None  # resolved at startup
        self.scanners = {}
        self.uni3_enabled = cfg.ENABLE_UNIV3_FLASH and db.get_meta(self.conn, "uni3_disabled") != "1"
        self.trace_mode = db.get_meta(self.conn, "trace_mode")  # resolved lazily
        self.http = httpx.AsyncClient()
        self.last_today_price = 0.0
        self.balance_off = False
        self.balance_ok = 0
        self.balance_fail = 0

    # ------------------------------------------------------------------ blocks
    async def block_ts(self, n: int) -> int:
        r = self.conn.execute("SELECT ts FROM block_meta WHERE block=?", (n,)).fetchone()
        if r and r[0]:
            return r[0]
        h = await self.rpc.block_header(n)
        ts = int(h["timestamp"], 16)
        self.conn.execute("INSERT OR REPLACE INTO block_meta(block,ts,miner) VALUES(?,?,?)",
                          (n, ts, (h.get("miner") or "").lower()))
        return ts

    async def block_miner(self, n: int) -> str:
        r = self.conn.execute("SELECT miner FROM block_meta WHERE block=?", (n,)).fetchone()
        if r and r[0]:
            return r[0]
        h = await self.rpc.block_header(n)
        miner = (h.get("miner") or "").lower()
        self.conn.execute("INSERT OR REPLACE INTO block_meta(block,ts,miner) VALUES(?,?,?)",
                          (n, int(h["timestamp"], 16), miner))
        return miner

    async def find_block_at(self, target_ts: int, head: int) -> int:
        head_ts = await self.block_ts(head)
        guess = max(1, head - (head_ts - target_ts) // 12)
        for _ in range(6):
            ts = await self.block_ts(guess)
            diff = ts - target_ts
            if abs(diff) < 24:
                break
            guess = max(1, guess - diff // 12)
        return guess

    # --------------------------------------------------------------- scanning
    def scanner(self, kind: str) -> LogScanner:
        key = (id(self.rpc), kind)
        if key not in self.scanners:
            self.scanners[key] = LogScanner(self.rpc, cfg.LOG_CHUNK, cfg.LOG_CHUNK_MAX)
        return self.scanners[key]

    async def scan_window(self, start: int, end: int) -> int:
        logs = await self.scanner("main").get_logs(
            {"address": C.PROVIDER_ADDRESSES, "topics": [C.PROVIDER_TOPICS]}, start, end)
        if self.uni3_enabled:
            try:
                logs += await self.scanner("uni3").get_logs({"topics": [C.T_UNI3_FLASH]}, start, end)
            except RpcError as e:
                log.warning("Uniswap V3 Flash scan disabled: RPC refused address-less filter (%s)", e.message[:150])
                self.uni3_enabled = False
                db.set_meta(self.conn, "uni3_disabled", "1")
        seen = {}
        for lg in logs:
            h = lg["transactionHash"].lower()
            if h in seen:
                continue
            b = int(lg["blockNumber"], 16)
            ts = lg.get("blockTimestamp")
            ts = int(ts, 16) if isinstance(ts, str) else (ts or 0)
            seen[h] = (b, ts)
        for h, (b, ts) in seen.items():
            if not ts:
                ts = await self.block_ts(b)
            self.conn.execute("INSERT OR IGNORE INTO pending(hash,block,ts) "
                              "SELECT ?,?,? WHERE NOT EXISTS (SELECT 1 FROM txs WHERE hash=?)", (h, b, ts, h))
        self.conn.commit()
        return len(seen)

    # ----------------------------------------------------------------- traces
    async def resolve_trace_mode(self, sample_hash: str):
        if self.trace_mode:
            return
        mode = cfg.TRACE_MODE
        if mode in ("trace", "debug", "off"):
            self.trace_mode = mode
        else:
            self.trace_mode = "off"
            for m in ("trace", "debug"):
                try:
                    r = await self.fetch_trace(sample_hash, m)
                    if r:
                        self.trace_mode = m
                        break
                except QuotaExceeded:
                    raise
                except Exception as e:  # noqa
                    log.info("trace method %s unavailable: %s", m, str(e)[:120])
        log.info("TRACE_MODE resolved -> %s", self.trace_mode)
        db.set_meta(self.conn, "trace_mode", self.trace_mode)
        self.conn.commit()

    async def fetch_trace(self, h: str, mode: str):
        if mode == "trace":
            return await self.rpc.call("trace_transaction", [h])
        if mode == "debug":
            return await self.rpc.call("debug_traceTransaction", [h, {"tracer": "callTracer"}])
        return None

    async def native_eth(self, a: dict) -> dict | None:
        """Native ETH delta for {tx.from, tx.to}: trace if available, else archive balance diff."""
        bene = {x for x in (a["from_addr"], a["to_addr"]) if x}
        await self.resolve_trace_mode(a["hash"])
        if self.trace_mode in ("trace", "debug"):
            try:
                tr = await self.fetch_trace(a["hash"], self.trace_mode)
                if tr:
                    miner = await self.block_miner(a["block"])
                    net, bribe = eth_flows_from_trace(tr, self.trace_mode, bene, miner)
                    return {"delta": net, "bribe": bribe, "mode": "trace"}
            except QuotaExceeded:
                raise
            except Exception as e:  # noqa
                log.debug("trace failed for %s: %s", a["hash"], e)
        if (self.rpc is self.rpc_live or self.archive is False) and self.head - a["block"] > 100:
            return None  # non-archive RPC keeps ~128 blocks of state; older balances are unavailable
        if self.balance_off:
            return None
        b, frm, to = a["block"], a["from_addr"], a["to_addr"]
        out = await self.rpc.batch_calls([
            ("eth_getBalance", [to, hex(b - 1)]), ("eth_getBalance", [to, hex(b)]),
            ("eth_getBalance", [frm, hex(b - 1)]), ("eth_getBalance", [frm, hex(b)]),
            ("eth_getTransactionCount", [frm, hex(b - 1)]), ("eth_getTransactionCount", [frm, hex(b)]),
        ])
        res, nonces = out[:4], out[4:]
        if any(r is None for r in res) or any(n is None for n in nonces):
            self.balance_fail += 1
            if self.balance_ok == 0 and self.balance_fail >= 25:
                log.warning("archive eth_getBalance unavailable on this RPC -> conservative ETH accounting")
                self.balance_off = True
            return None
        self.balance_ok += 1
        if int(nonces[1], 16) - int(nonces[0], 16) != 1:
            return None  # same EOA sent other txs in this block -> balance diff not attributable
        v = [int(x, 16) for x in res]
        delta = (v[1] - v[0]) + (v[3] - v[2]) + a["gas_fee_wei"]  # gas is accounted separately
        return {"delta": delta, "bribe": 0, "mode": "balance"}

    # ------------------------------------------------------------- uni3 pools
    async def uni3_tokens(self, pools: set[str]) -> dict:
        out = {}
        missing = []
        for p in pools:
            r = self.conn.execute("SELECT token0, token1 FROM uni3_pools WHERE pool=?", (p,)).fetchone()
            if r:
                out[p] = (r[0], r[1])
            else:
                missing.append(p)
        for p in missing:
            try:
                t0 = await self.rpc.call("eth_call", [{"to": p, "data": C.SEL_TOKEN0}, "latest"])
                t1 = await self.rpc.call("eth_call", [{"to": p, "data": C.SEL_TOKEN1}, "latest"])
                toks = ("0x" + t0[-40:].lower(), "0x" + t1[-40:].lower())
                self.conn.execute("INSERT OR REPLACE INTO uni3_pools VALUES(?,?,?)", (p, *toks))
                out[p] = toks
            except QuotaExceeded:
                raise
            except Exception as e:  # noqa
                log.debug("uni3 token lookup failed for %s: %s", p, e)
        return out

    # --------------------------------------------------------------- receipts
    async def process_pending(self, lo: int = 0, hi: int = 1 << 62):
        while True:
            rows = self.conn.execute(
                "SELECT hash, block, ts, tries FROM pending WHERE tries < 6 AND block BETWEEN ? AND ? "
                "ORDER BY block LIMIT ?", (lo, hi, cfg.RECEIPT_BATCH * cfg.CONCURRENCY * 4)).fetchall()
            if not rows:
                return
            sem = asyncio.Semaphore(cfg.CONCURRENCY)
            batches = [rows[i:i + cfg.RECEIPT_BATCH] for i in range(0, len(rows), cfg.RECEIPT_BATCH)]

            async def one(batch):
                async with sem:
                    res = await self.rpc.batch("eth_getTransactionReceipt", [[r["hash"]] for r in batch])
                    for r, rc in zip(batch, res):
                        if not rc:
                            self.conn.execute("UPDATE pending SET tries=tries+1 WHERE hash=?", (r["hash"],))
                            continue
                        try:
                            await self.store_receipt(rc, r["ts"])
                            self.conn.execute("DELETE FROM pending WHERE hash=?", (r["hash"],))
                        except QuotaExceeded:
                            raise
                        except Exception as e:  # noqa
                            log.exception("decode failed %s: %s", r["hash"], e)
                            self.conn.execute("UPDATE pending SET tries=tries+1 WHERE hash=?", (r["hash"],))

            await asyncio.gather(*(one(b) for b in batches))
            self.conn.commit()

    async def store_receipt(self, rc: dict, ts: int):
        uni3_pools = {lg["address"].lower() for lg in rc.get("logs", [])
                      if lg.get("topics") and lg["topics"][0].lower() == C.T_UNI3_FLASH}
        toks = await self.uni3_tokens(uni3_pools) if uni3_pools else {}
        a = analyze_receipt(rc, toks)
        candidate = a["n_swaps"] >= 2 and a["n_pools"] >= 2 and not a["liquidations"]
        if candidate and cfg.NATIVE_ONLY_WHEN_NEEDED:
            # native ETH only matters if a native-ETH venue was touched, WETH was unwrapped, or nothing
            # observable reached the bot (profit may have arrived as ETH)
            candidate = (any(v in ("UniV4", "Curve") for v in a["venues"]) or a["flows"].get(C.WETH, 0) < 0
                         or not a["flows"])
        if candidate:
            native = await self.native_eth(a)
            if native is not None:
                a = analyze_receipt(rc, toks, native=native)
        if not a["flashloans"]:
            return
        c = self.conn
        c.execute("""INSERT OR REPLACE INTO txs(hash,block,ts,day,from_addr,to_addr,gas_used,gas_price,gas_fee_wei,
                     n_swaps,n_pools,venues,providers,liquidations,eth_mode,bribe_wei,priced_at)
                     VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,NULL)""",
                  (a["hash"], a["block"], ts, day_of(ts), a["from_addr"], a["to_addr"], a["gas_used"],
                   str(a["gas_price"]), str(a["gas_fee_wei"]), a["n_swaps"], a["n_pools"],
                   ",".join(a["venues"]), ",".join(sorted({f["provider"] for f in a["flashloans"]})),
                   ",".join(a["liquidations"]), a["eth_mode"], str(a["bribe_wei"])))
        c.execute("DELETE FROM flows WHERE hash=?", (a["hash"],))
        c.executemany("INSERT INTO flows(hash,token,delta) VALUES(?,?,?)",
                      [(a["hash"], t, str(v)) for t, v in a["flows"].items()])
        c.executemany("INSERT OR REPLACE INTO flashloans(hash,log_index,provider,token,amount,fee,receiver) "
                      "VALUES(?,?,?,?,?,?,?)",
                      [(a["hash"], f["log_index"], f["provider"], f["token"], str(f["amount"]), str(f["fee"]),
                        f["receiver"]) for f in a["flashloans"]])

    # ---------------------------------------------------------------- pricing
    async def price_step(self, force_today: bool = False):
        now = int(time.time())
        today = day_of(now)
        days = [r[0] for r in self.conn.execute(
            "SELECT DISTINCT day FROM txs WHERE priced_at IS NULL ORDER BY day").fetchall()]
        refresh_today = force_today or (now - self.last_today_price > 1800)
        if refresh_today and today not in days and self.conn.execute(
                "SELECT 1 FROM txs WHERE day=? LIMIT 1", (today,)).fetchone():
            days.append(today)
        for d in days:
            await self.price_day(d, now, refresh=(d == today and refresh_today))
            if d == today and refresh_today:
                self.last_today_price = now

    async def price_day(self, d: str, now: int, refresh: bool):
        c = self.conn
        day_start = int(datetime.strptime(d, "%Y-%m-%d").replace(tzinfo=timezone.utc).timestamp())
        ts = min(day_start + 43200, now - 120)
        toks = {r[0] for r in c.execute(
            "SELECT DISTINCT f.token FROM flows f JOIN txs t ON t.hash=f.hash WHERE t.day=?", (d,))}
        toks |= {r[0] for r in c.execute(
            "SELECT DISTINCT f.token FROM flashloans f JOIN txs t ON t.hash=f.hash WHERE t.day=?", (d,))}
        toks.discard(C.ETH_PSEUDO)
        toks.add(C.WETH)
        if refresh:
            need = sorted(toks)
        else:
            have = {r[0] for r in c.execute("SELECT token FROM prices WHERE day=?", (d,))}
            need = sorted(toks - have)
        if need:
            got = await fetch_prices(self.http, cfg.PRICE_API, ts, need)
            for t in need:
                v = got.get(t)
                if v:
                    c.execute("INSERT OR REPLACE INTO prices VALUES(?,?,?,?,?)",
                              (d, t, v.get("price"), v.get("confidence", 1.0), now))
                    if v.get("decimals") is not None:
                        c.execute("INSERT OR REPLACE INTO tokens VALUES(?,?,?)", (t, v.get("symbol"), v["decimals"]))
                else:
                    c.execute("INSERT OR REPLACE INTO prices VALUES(?,?,NULL,NULL,?)", (d, t, now))
        price = {r[0]: (r[1], r[2]) for r in c.execute("SELECT token, price, confidence FROM prices WHERE day=?", (d,))}
        dec = {r[0]: r[1] for r in c.execute("SELECT token, decimals FROM tokens")}
        ethp = (price.get(C.WETH) or (None, None))[0]
        if not ethp:
            log.warning("no ETH price for %s yet; will retry", d)
            c.commit()
            return
        where = "day=?" if refresh else "day=? AND priced_at IS NULL"
        txs = c.execute(f"SELECT hash, gas_fee_wei, bribe_wei, n_swaps, n_pools, liquidations, eth_mode, venues "
                        f"FROM txs WHERE {where}",
                        (d,)).fetchall()
        for t in txs:
            h = t["hash"]
            usd_deltas = {}
            gross = 0.0
            priced = unpriced = 0
            for fr in c.execute("SELECT token, delta FROM flows WHERE hash=?", (h,)):
                tok, delta = fr[0], int(fr[1])
                key = C.WETH if tok == C.ETH_PSEUDO else tok
                p, conf = price.get(key, (None, None))
                dd = 18 if tok == C.ETH_PSEUDO else dec.get(key)
                if p is None or dd is None or (conf is not None and conf < cfg.MIN_PRICE_CONFIDENCE):
                    usd_deltas[tok] = math.copysign(math.inf, delta)
                    unpriced += 1
                    continue
                v = delta / (10 ** dd) * p
                if abs(v) > cfg.MAX_TOKEN_DELTA_USD:
                    usd_deltas[tok] = math.copysign(math.inf, delta)
                    unpriced += 1
                    continue
                usd_deltas[tok] = v
                gross += v
                priced += 1
            gas_usd = int(t["gas_fee_wei"]) / 1e18 * ethp
            bribe_usd = int(t["bribe_wei"] or 0) / 1e18 * ethp
            flash_usd = fee_usd = 0.0
            for fl in c.execute("SELECT token, amount, fee FROM flashloans WHERE hash=?", (h,)):
                p, _ = price.get(fl[0], (None, None))
                dd = dec.get(fl[0])
                if p is not None and dd is not None:
                    flash_usd += int(fl[1]) / 10 ** dd * p
                    fee_usd += int(fl[2]) / 10 ** dd * p
            liqs = [x for x in (t["liquidations"] or "").split(",") if x]
            cat = classify(t["n_swaps"], t["n_pools"], liqs, usd_deltas, gross_usd=gross, flash_usd=flash_usd,
                           max_margin=cfg.ARB_MAX_MARGIN)
            weth = c.execute("SELECT delta FROM flows WHERE hash=? AND token=?", (h, C.WETH)).fetchone()
            rel = is_reliable(cat, t["eth_mode"], t["venues"], unpriced, int(weth[0]) if weth else 0,
                              n_flows=priced + unpriced)
            c.execute("""UPDATE txs SET category=?, gross_usd=?, gas_usd=?, bribe_usd=?, net_usd=?, flash_usd=?,
                         fee_usd=?, priced_tokens=?, unpriced_tokens=?, reliable=?, priced_at=? WHERE hash=?""",
                      (cat, gross, gas_usd, bribe_usd, gross - gas_usd, flash_usd, fee_usd, priced, unpriced,
                       int(rel), now, h))
        c.commit()
        log.info("priced %s: %d txs", d, len(txs))

    # ------------------------------------------------------------------ prune
    def prune(self):
        cutoff = int(time.time() - (cfg.LOOKBACK_DAYS + 1) * 86400)
        c = self.conn
        c.execute("DELETE FROM flows WHERE hash IN (SELECT hash FROM txs WHERE ts < ?)", (cutoff,))
        c.execute("DELETE FROM flashloans WHERE hash IN (SELECT hash FROM txs WHERE ts < ?)", (cutoff,))
        c.execute("DELETE FROM txs WHERE ts < ?", (cutoff,))
        c.execute("DELETE FROM pending WHERE ts < ?", (cutoff,))
        c.execute("DELETE FROM block_meta WHERE ts < ?", (cutoff,))
        c.execute("DELETE FROM prices WHERE day < ?", (day_of(cutoff),))
        c.commit()

    # ------------------------------------------------------------------- main
    def save_credits(self):
        db.set_meta(self.conn, "credit_day", self.rpc_hist.credit_day)
        db.set_meta(self.conn, "credits_today", self.rpc_hist.credits_today)

    async def step(self, lo: int, hi: int, label: str):
        t0 = time.time()
        self.rpc = self.rpc_hist if label == "history" else self.rpc_live
        try:
            n = await self.scan_window(lo, hi)
            await self.process_pending(lo, hi)
        finally:
            self.rpc = self.rpc_live
        await self.price_step()
        self.save_credits()
        log.info("%s blocks %d..%d: %d flash-loan txs (%.1fs, archive credits today=%d)", label, lo, hi, n,
                 time.time() - t0, self.rpc_hist.credits_today)

    async def init_state(self):
        self.head = await self.rpc_live.block_number() - cfg.CONFIRMATIONS
        if self.archive is None:
            try:
                await self.rpc_hist.call("eth_getBalance", [C.WETH, hex(self.head - 5000)])
                self.archive = True
            except QuotaExceeded:
                raise
            except Exception:  # noqa
                self.archive = False
            db.set_meta(self.conn, "archive", int(self.archive))
            log.info("archive state available: %s", self.archive)
        if db.get_meta(self.conn, "live_cursor") is None:
            target = await self.find_block_at(int(time.time() - cfg.LOOKBACK_DAYS * 86400), self.head)
            db.set_meta(self.conn, "backfill_target", target)
            db.set_meta(self.conn, "backfill_start", target)
            db.set_meta(self.conn, "back_cursor", self.head + 1)  # lowest block already covered
            db.set_meta(self.conn, "live_cursor", self.head)      # highest block already covered
            db.set_meta(self.conn, "backfill_done", 0)
            self.conn.commit()
            log.info("new index: live from block %d, history back to block %d (%.1f days)", self.head, target,
                     cfg.LOOKBACK_DAYS)

    async def run(self):
        while True:
            try:
                await self.init_state()
                break
            except QuotaExceeded as e:
                await self.quota_sleep(e)
            except Exception as e:  # noqa
                log.exception("startup failed: %s", e)
                await asyncio.sleep(30)
        while True:
            try:
                self.head = await self.rpc_live.block_number() - cfg.CONFIRMATIONS
                db.set_meta(self.conn, "head", self.head)
                # 1) live first: keep the newest data flowing
                cur = int(db.get_meta(self.conn, "live_cursor"))
                while cur < self.head:
                    hi = min(self.head, cur + WINDOW)
                    await self.step(cur + 1, hi, "live")
                    cur = hi
                    db.set_meta(self.conn, "live_cursor", cur)
                    db.set_meta(self.conn, "updated_at", int(time.time()))
                    self.conn.commit()
                # 2) then extend history backwards for a bounded time slice
                done = db.get_meta(self.conn, "backfill_done") == "1"
                paused = time.time() < int(db.get_meta(self.conn, "quota_until", 0) or 0)
                t_end = time.time() + cfg.BACKFILL_SLICE_SECONDS
                while not done and not paused and time.time() < t_end:
                    db.set_meta(self.conn, "status", "backfilling")
                    back = int(db.get_meta(self.conn, "back_cursor"))
                    target = int(db.get_meta(self.conn, "backfill_target"))
                    hi = back - 1
                    lo = max(target, hi - WINDOW + 1)
                    if hi < target:
                        done = True
                    else:
                        try:
                            await self.step(lo, hi, "history")
                            db.set_meta(self.conn, "back_cursor", lo)
                            done = lo <= target
                        except QuotaExceeded as e:
                            if self.rpc_hist is self.rpc_live:
                                raise
                            # archive key exhausted: pause history only, live keeps running on the free RPC
                            resume = (int(time.time() // 86400) + 1) * 86400 + 300
                            db.set_meta(self.conn, "quota_until", resume)
                            log.warning("archive RPC quota reached (%s); history paused until %s UTC", str(e)[:120],
                                        datetime.fromtimestamp(resume, tz=timezone.utc).strftime("%Y-%m-%d %H:%M"))
                            self.save_credits()
                            paused = True
                        except RpcError as e:
                            if not is_history_error(e):
                                raise
                            log.warning("RPC has no history before block ~%d (%s) -> history stops here; "
                                        "data will accumulate going forward", hi, e.message[:120])
                            db.set_meta(self.conn, "history_floor", back)
                            done = True
                    if done:
                        db.set_meta(self.conn, "backfill_done", 1)
                    db.set_meta(self.conn, "updated_at", int(time.time()))
                    self.conn.commit()
                await self.process_pending(self.head - 100, self.head)  # leftovers near head (live RPC)
                if not paused:
                    self.rpc = self.rpc_hist
                    try:
                        await self.process_pending(0, self.head - 101)   # older leftovers (archive RPC)
                    except QuotaExceeded:
                        if self.rpc_hist is self.rpc_live:
                            raise
                    finally:
                        self.rpc = self.rpc_live
                await self.price_step()
                self.prune()
                self.save_credits()
                if paused:
                    db.set_meta(self.conn, "status", "history_paused")
                else:
                    db.set_meta(self.conn, "status", "live" if done else "backfilling")
                    db.set_meta(self.conn, "quota_until", 0)
                db.set_meta(self.conn, "updated_at", int(time.time()))
                self.conn.commit()
                if not done and not paused:
                    continue  # keep backfilling (live is re-checked first every slice)
            except QuotaExceeded as e:
                await self.quota_sleep(e)
                continue
            except Exception as e:  # noqa
                log.exception("indexer loop error: %s", e)
                db.set_meta(self.conn, "last_error", f"{int(time.time())}: {str(e)[:300]}")
                self.conn.commit()
            await asyncio.sleep(cfg.POLL_SECONDS)

    async def quota_sleep(self, e: Exception):
        now = time.time()
        resume = (int(now // 86400) + 1) * 86400 + 300  # 00:05 UTC next day
        log.warning("quota reached (%s); sleeping until %s UTC", str(e)[:150],
                    datetime.fromtimestamp(resume, tz=timezone.utc).strftime("%Y-%m-%d %H:%M"))
        self.save_credits()
        db.set_meta(self.conn, "status", "quota_wait")
        db.set_meta(self.conn, "quota_until", resume)
        db.set_meta(self.conn, "updated_at", int(now))
        self.conn.commit()
        while time.time() < resume:
            await asyncio.sleep(min(600, resume - time.time()))
        self.rpc_hist.credits_today = 0


def main():
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
    logging.getLogger("httpx").setLevel(logging.WARNING)
    asyncio.run(Indexer().run())


if __name__ == "__main__":
    main()
